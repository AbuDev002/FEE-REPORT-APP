<?php
        //session_start();
		ob_start();
		//error_reporting(1);
		require_once 'dompdf/autoload.inc.php';
		
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<?php
	if(isset($_GET['stdreport'])){
	$regno = $_GET['search'];
	//$session = $_GET['session'];
	
	}
?>
<!Doctype html>
<html>
	<head>
		<title>Student Fee Report</title>
		
		<style type="text/css">
			#container{
				width:1200px;
				height:auto;
				margin:0px auto;
				text-indent:5px;
                               
			}
			
			
			th#mdb{
				background-image:url("images/logo.png") no-repeat;
				background-size:contain;
			}
			
			#invt_details td{
				border:1px solid silver;
				border-collapse:collapse;
			}
			
			.head{
				background:#91C5D4;
				}
		@page { margin: 180px 50px; }
			#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 120px; background-color: #f5f5f5; text-align: center; width:100%; }
			#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 100px; background-color: #f5f5f5; }
			#footer .page:after { content: counter(page, upper-roman); }
			
			table#firstsemster_gp{page-bread-after:auto;}
			table#firstsemster_gp tr{page-bread-after:auto;page-break-inside:avoid}
			table#firstsemster_gp td{page-bread-after:auto;page-break-inside:avoid}
			table#firstsemster_gp thead{display:table-header-group;}
			table#firstsemster_gp tfoot{display:table-footer-group;}
			
			/*table#secondsemster_gp tr td, table#secondsemster_gp tr th{page-break-after:auto;}
			table#thirdsemster_gp tr td, table#thirdsemster_gp tr th{page-break-after:auto;}
			table#fourthsemster_gp tr td, table#fourthsemster_gp tr th{page-break-after:auto;}*/
		  
		</style>
	</head>
	
<body>
<div id="container">
	
<div id="header">
		<table align="center"  width="100%" style="font-size:12px; border-collapse:collapse;">
			<tr>
				<td colspan="3" align="center"><img src="http://localhost/feereportsystem/assets/images/logo/polylogo.jpg" width="50" height="50"></i></h3></td>
			</tr>
			<tr>
				<td colspan="3" align="center"><h3>FEDERAL POLYTECHNIC BAUCHI,<br/> <i>P.M.B 0231 BAUCHI, BAUCHI STATE</i></h3></td>
			</tr>
			
			<tr>
				<td></td>
				<td align="center"><br/><h2 style="padding:0px; background:#000; color:#fff;">STUDENT LEDGER RECORDS</h2></td>
				<td></td>
			</tr>
			
		</table>
		<br/>
		<br/>
		
		<table width="70%" align="center" border="0" style="font-size:16px; border-collapse:collapse;">
			
			<?php
				//$getstudents_qry = $db->select("select * from student where admin_no='".$regno."'");
				$getstudents_qry = $db->select("SELECT * FROM student as std JOIN feerecord as fr WHERE std.dept_id = fr.dept_id AND std.class_id = fr.class_id AND std.admin_no='".$regno."'");
				if(@mysqli_num_rows($getstudents_qry) > 0){
				while($getstudent_rs = $getstudents_qry->fetch_assoc()){
					$stdid =  $getstudent_rs['id'];
					$regno =  $getstudent_rs['admin_no'];
					$sname =  $getstudent_rs['sname'];
					$dept =  $getstudent_rs['dept_id'];
					$program_session =  $getstudent_rs['joindate'];
					$amountpayed = $getstudent_rs['amount_payed'];
					$paymenttype = $getstudent_rs['payment_type'];
					$course_option =  $getstudent_rs['option_id'];
					$stdclass =  $getstudent_rs['class_id'];
					$stream =  $getstudent_rs['stream_id'];
					$registration =  $getstudent_rs['registration'];
					$exams =  $getstudent_rs['exams'];
					$games =  $getstudent_rs['games'];
					$library =  $getstudent_rs['library'];
					$idcard =  $getstudent_rs['idcard'];
					$verification =  $getstudent_rs['verification'];
					$prospect =  $getstudent_rs['prospect'];
					$medical =  $getstudent_rs['medical'];
					$technology =  $getstudent_rs['technology'];
					$practical =  $getstudent_rs['practical'];
					$tuition =  $getstudent_rs['tuition'];
					$endowment =  $getstudent_rs['endowment'];
					$eed =  $getstudent_rs['eed'];
					$siwes =  $getstudent_rs['siwes'];
					$accomodation =  $getstudent_rs['accomodation'];
					$total = $registration + $exams + $games + $library + $idcard + $verification + $prospect + $medical + $technology + $practical + $tuition + $endowment + $eed + $siwes + $accomodation;
					 $fee = $total - $accomodation;
					}
				}else{
					echo "<script>alert('Sorry No record found')</script>";
						echo "<script>window.open('students.php','_self')</script>";
				}
			?>
			<tr>
				<td><b>Name:</b> <?php echo $sname;?></td>
				<td></td>
			</tr>
			<tr>
				<td><b>Reg. No.:</b> <?php echo $regno;?></td>
				<td></td>
			</tr>
			<tr>
				<td><b>Department:</b> <?php 
						 $getdept_sql ="SELECT * FROM departments WHERE dept_id =$dept";
						 $getdept_qry = $db->select($getdept_sql);
						 $getdept_rs = $getdept_qry->fetch_assoc();
						 echo $getdept_rs['department'];
				   ?></td>
				<td>
					
				</td>
			</tr>
			<tr>
				<td><b>Option:</b> <?php 
						 $getoption_sql ="SELECT * FROM course_option WHERE id =$course_option";
						 $getoption_qry = $db->select($getoption_sql);
						 $getoption_rs = $getoption_qry->fetch_assoc();
						 echo $getoption_rs['course_option'];
				   ?></td>
				<td>
					
				</td>
			</tr>
			<tr>
				<td><b>Class:</b> <?php 
						 $getclass_sql ="SELECT * FROM addclass WHERE classid =$stdclass";
						 $getclass_qry = $db->select($getclass_sql);
						 $getclass_rs = $getclass_qry->fetch_assoc();
						 echo $getclass_rs['classname'];
				   ?></td>
				<td>
					
				</td>
			</tr>
			<tr>
				<td><b>Stream:</b>  <?php 
						 $getstream_sql ="SELECT * FROM stream WHERE stream_id =$stream";
						 $getstream_qry = $db->select($getstream_sql);
						 $getstream_rs = $getstream_qry->fetch_assoc();
						 echo $getstream_rs['stream_name'];
				   ?></td>
				<td>
					
				  
				</td>
			</tr>
			<tr>
				<td><b>School Fees:</b> <?php echo number_format($total, 2, '.', ',');?>  </td>
				<td>
					
				  
				</td>
			</tr>
			<tr>
				<td><b>School Fees (No Accomodation):</b> <?php echo number_format($fee, 2, '.', ',');?> </td>
				<td>
					
				  
				</td>
			</tr>
		</table>
		<br/>
		<br/>
		<table width="70%" align="center"  style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td><b>Session/Year</b></td>
				<td><b><?php echo date("Y") - 1;?></b></td>
			</tr>
		</table>
		<table width="70%" align="center" border="1" style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td align="center"><b>DATE</b></td>
				<td align="center"><b>PARTICULARS</b></td>
				<td align="center"><b>REF</b></td>
				<td align="center"><b>DR</b></td>
				<td align="center"><b>CR</b></td>
				<td align="center"><b>BALANCE</b></td>
			</tr>
			<tr>
				<td align="center"><?php echo $program_session;?></td>
				<td align="center">
					<p>SCHOOL FEES: <b><?php echo number_format($amountpayed, 2, '.', ',');?></b></p> 
					<p>ACCOMODATION:</p> 
					<p>CASH PAID VIA: <b><?php echo $paymenttype;?></b></p>
				</td>
				<td align="center"></td>
				<td align="center"><?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?></td>
				<td align="center" style="height:100px;">
					<br/>
					<br/>
					<br/>
					<br/>
					<?php echo '<strong>'.number_format($amountpayed, 2, '.', ',').'</strong>';?>
				</td>
				<td align="center">
					<br/>
					<br/>
					<br/>
					<br/>
					<?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?>
				</td>
			</tr>
			<tr>
				<td align="center"><b>Total</b></td>
				<td align="center"></td>
				<td align="center"></td>
				<td align="center"><?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?></td>
				<td align="center"></td>
				<td align="center"></td>
				
			</tr>
		</table>
		<br/>
		<br/>
		<table width="70%" align="center"  style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td><b>Session/Year</b></td>
				<td><b><?php echo date("Y");?></b></td>
			</tr>
		</table>
		<table width="70%" align="center" border="1" style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td align="center"><b>DATE</b></td>
				<td align="center"><b>PARTICULARS</b></td>
				<td align="center"><b>REF</b></td>
				<td align="center"><b>DR</b></td>
				<td align="center"><b>CR</b></td>
				<td align="center"><b>BALANCE</b></td>
			</tr>
			<tr>
				<td align="center"><?php echo $program_session;?></td>
				<td align="center">
					<p>SCHOOL FEES: <b><?php echo number_format($amountpayed, 2, '.', ',');?></b></p> 
					<p>ACCOMODATION:</p> 
					<p>CASH PAID VIA: <b><?php echo $paymenttype;?></b></p>
				</td>
				<td align="center"></td>
				<td align="center" style="border-right:0px;"><?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?></td>
				<td align="center" style="height:100px;border-right:0px;">
					<br/>
					<br/>
					<br/>
					<br/>
					<?php echo '<strong>'.number_format($amountpayed, 2, '.', ',').'</strong>';?>
				</td>
				<td align="center">
				<br/>
					<br/>
					<br/>
					<br/>
				<?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?>
				</td>
			</tr>
			<tr>
				<td align="center"><b>Total</b></td>
				<td align="center"></td>
				<td align="center"></td>
				<td align="center"><?php echo '<strong>'.number_format($total, 2, '.', ',').'</strong>';?></td>
				<td align="center"></td>
				<td align="center"></td>
				
			</tr>
		</table>
		<br/>
		<br/>
		<h3>Fee Details</h3>
		<table width="70%" align="center" border="1" style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td align="center">Registration Fee: <?php echo $registration;?></td>
				<td align="center">Exams: <?php echo $exams;?></td>
				<td align="center">Games: <?php echo $games;?></td>
				<td align="center">Library: <?php echo $library;?></td>
				<td align="center">ID Card: <?php echo $idcard;?></td>
				<td align="center">Verification: <?php echo $prospect;?></td>
				<td align="center">Medical: <?php echo $medical;?></td>
				
			</tr>
		</table>
		<br>
		<table width="70%" align="center" border="1" style="font-size:16px; border-collapse:collapse;">
			<tr>
				<td align="center">Technology: <?php echo $technology;?></td>
				<td align="center">Practical: <?php echo $practical;?></td>
				<td align="center">Tuition: <?php echo $tuition;?></td>
				<td align="center">Endownment: <?php echo $endowment;?></td>
				<td align="center">EED: <?php echo $eed;?></td>
				<td align="center">SIWES: <?php echo $siwes;?></td>
				<td align="center">Accomodation: <?php echo $accomodation;?></td>
			</tr>
		</table>
</div>
	<div id="footer">
	<hr/>
	<br>
	<?php echo date('F j, Y');?>
	</div>	
			
	</div>				   
	</body>
</html>
<?php		
	$html = ob_get_clean();
	use Dompdf\Dompdf;
	$dompdf = new DOMPDF();
	$dompdf->set_paper("Legal","A4");
	$dompdf->load_html($html);
	$dompdf->render();
	$dompdf->stream('fees_report.pdf');
?>