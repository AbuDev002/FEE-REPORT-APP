
<!DOCTYPE html>
<html lang="en">
<head>
    <title>iTech | Edit/View Student</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://preview.thesoftking.com/thesoftking/itech/assets/images/logo/favicon.png" />
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/font-awesome.min.css">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/bootstrap-toggle.min.css" rel="stylesheet">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/bootstrap-fileinput.css" rel="stylesheet">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/toastr.min.css" rel="stylesheet" type="text/css"/>
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/table.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/custom.css">

    <script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/sweetalert.js"></script>
    <link rel="stylesheet" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/sweetalert.css">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/color.php?color=2ecc71" rel="stylesheet">
    <style>
        a.app-header__logo {
            font-size: 20px;
        }

        .app-title{
            background-color:white;
        }
    </style>
        <style>
        .box {
            background-color: #fff;
            border: 1px solid #ddd;
            display: block;
            max-width: 30em;
            margin: 0 auto;
            border-radius: 4px;
        }
        .box header {
            border-bottom: 1px solid #ddd;
            padding: 0.5em 1em;
            margin-bottom: 1em;
        }
        .box .content {
            padding: 1em;
        }

        .left, .right {
            display: table-cell;
            vertical-align: middle;
        }

        .left {
            width: 6em;
            min-width: 6em;
            padding-right: 1em;
        }
        .left img {
            width: 100%;
        }

        .img-holder {
            display: block;
            vertical-align: middle;
            width: 2em;
            height: 2em;
        }
        .img-holder img {
            width: 100%;
            max-width: 100%;
        }

        .file-wrapper {
            cursor: pointer;
            display: inline-block;
            overflow: hidden;
            position: relative;
        }
        .file-wrapper:hover .btn {
            background-color: #33adff !important;
        }

        .file-wrapper input {
            cursor: pointer;
            font-size: 100px;
            height: 100%;
            filter: alpha(opacity=1);
            -moz-opacity: 0.01;
            opacity: 0.01;
            position: absolute;
            right: 0;
            top: 0;
            z-index: 9;
        }
        span.file-holder {
            display: none;
        }
    </style>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<header class="app-header"><a class="app-header__logo" href="http://preview.thesoftking.com/thesoftking/itech">iTech</a>
    <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
    <!-- Navbar Right Menu-->
    <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">admin <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/change-password"><i class="fa fa-cog fa-lg"></i> Password Settings</a></li>
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/profile"><i class="fa fa-user fa-lg"></i> Profile</a></li>
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/logout"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
    <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" class="img-circle" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/img/admin_1531922370.jpg" alt="User Image">
        <div>
            <p class="app-sidebar__user-name">Admin </p>
            <p class="app-sidebar__user-designation">admin</p>
        </div>
    </div>
    <ul class="app-menu">
        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/category"><i class="app-menu__icon fa fa-sitemap"></i><span class="app-menu__label">Manage Department</span></a></li>

        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/student"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Student</span></a></li>


        <li class="treeview ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-money"></i><span class="app-menu__label">Payment Management </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/create/invoice"><i class="icon fa fa-hand-o-right"></i> Due Monthly Payment </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/payment/detail"><i class="icon fa fa-hand-o-right"></i> Student Payment Reports </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/income"><i class="icon fa fa-hand-o-right"></i> Income Panel </a></li>
            </ul>
        </li>

        <li class="treeview ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-credit-card-alt"></i><span class="app-menu__label">Expense Management </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/expense"><i class="icon fa fa-plus-circle"></i> Create Expense </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/expense/report/search"><i class="icon fa fa-list-alt"></i> Expense Reports </a></li>
            </ul>
        </li>




        <li class="treeview ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cogs"></i><span class="app-menu__label">Settings</span><i class="treeview-indicator fa fa-angle-right"></i>
            </a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/general-settings"><i class="icon fa fa-cogs"></i> General Setting </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/manage-logo"><i class="icon fa fa-photo"></i> Logo & favicon </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/template"><i class="icon fa fa-envelope"></i> Email Setting</a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/sms-api"><i class="icon fa fa-mobile"></i> SMS Setting</a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/contact-setting"><i class="icon fa fa-phone"></i> Contact Setting </a></li>
            </ul>
        </li>

        <li><a class="app-menu__item" href="#genInv" data-toggle="modal" ><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">Generate Invoice</span></a></li>
    </ul>
</aside><main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i> Edit/View Student</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12">
                    </div>
    </div>

    <form id="form" method="POST" action="http://preview.thesoftking.com/thesoftking/itech/admin/student/4" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">        <input type="hidden" name="_method" value="put">        <div class="row">
            <div class="col-md-4">
                <div class="tile">
                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Personal Information</h4>
                    <div class="tile-body">


                        <div class="form-group">
                            <div class="left">
                                <img id="img-uploaded" src="http://preview.thesoftking.com/thesoftking/itech/assets/images/student/photo/1533454960.jpg" alt="your image" />
                            </div>
                            <div class="right">

                                <input type="text" style="display: none" class="img-path" placeholder="Image Path">
                                <span class="file-wrapper">
  <input type="file" name="photo" id="imgInp" value="" class="uploader" />
  <span class="btn btn-large btn-alpha btn-primary">Upload Image</span>
</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label> <strong>Name</strong></label>
                            <input type="text" name="name" value="Protik Hasan" class="form-control input-lg" >
                        </div>
                        <div class="form-group">
                            <label><strong>Phone</strong></label>
                            <input type="text" name="mobile" value="3456789" class="form-control input-lg">
                        </div>
                        <div class="form-group">
                            <label><strong>Email</strong></label>
                            <input type="email" name="email" value="hadsan@gmail.com" class="form-control input-lg">
                        </div>
                        <div class="form-group">
                            <label><strong>Birth Day</strong></label>
                            <div class="input-group">
                                <input type="text" class="form-control input-lg" name="b_day" value="2018-06-13" id="demoDate" placeholder="Select Date" required>
                                <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-calendar"></i>
                                            </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><strong>Religion</strong></label>
                            <select name="religion"  class="form-control">
                                <option  value="Islam">Islam</option>
                                <option  value="Hinduism">Hinduism</option>
                                <option selected value="Christianity">Christianity</option>
                                <option  value="Buddhism">Buddhism</option>
                                <option  value="Others">Others</option>
                            </select>

                        </div>
                        <div class="form-group">
                            <label><strong>Gender</strong></label>
                            <input data-toggle="toggle" data-on="Male" value="" data-off="Female" data-onstyle="success" data-offstyle="info"
                                   data-width="100%" type="checkbox"
                                   name="gender">
                        </div>

                        <div class="form-group">
                            <label><strong>Status</strong></label>
                            <input data-toggle="toggle" data-on="Active" checked data-off="Dective" data-onstyle="success" data-offstyle="danger"
                                   data-width="100%" type="checkbox"
                                   name="status">
                        </div>
                    </div>
                </div>

                <div class="tile">
                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Guardian Information</h4>
                    <div class="tile-body">

                        <div class="form-group">
                            <label> <strong>Guardian Name</strong></label>
                            <input type="text" name="guardian_name" value="Pranto Roy" class="form-control input-lg" >
                        </div>
                        <div class="form-group">
                            <label><strong>Guardian Phone</strong></label>
                            <input type="text" name="guardian_phone" value="3456734567" class="form-control input-lg">
                        </div>
                        <div class="form-group">
                            <label><strong>Guardian Email<small>(Optional)</small></strong></label>
                            <input type="email" name="guardian_email" value="www.prantoroy.com@gmail.com" class="form-control input-lg">
                        </div>
                        <div class="form-group">
                            <label><strong>Guardian Occupation </strong></label>
                            <input type="text"  name="guardian_ocu" value="Service Holder" class="form-control input-lg">
                        </div>
                        <div class="form-group">
                            <label><strong>Relation With Student</strong></label>
                            <input type="text" name="guardian_relation" value="Brother" class="form-control input-lg">
                        </div>

                    </div>
                </div>

            </div>

            <div class="col-md-8">
                <div class="tile">
                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Admission Information</h4>
                    <div class="tile-body">
                        <div class="form-group row">
                            <div class="col-md-4">
                                <label><strong>Admission Roll</strong></label>
                                <input type="number" name="admission_number" value="765756" class="form-control input-lg" >
                            </div>

                            <div class="col-md-4">
                                <label><strong>Roll</strong></label>
                                <input type="number" name="roll" value="7765756" class="form-control input-lg" >
                            </div>

                            <div class="col-md-4">
                                <label><strong>Join Date</strong></label>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" name="join_date" id="demoDate1" value="2018-08-05" placeholder="Select Date" required>
                                    <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-calendar"></i>
                                            </span>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label><strong>Select Category</strong></label>
                                <select class="form-control" name="cat_id" id="department">
                                                                            <option  value="4">Varsity Admission Eng</option>
                                                                            <option  value="6">Varsity Admission (Medical)</option>
                                                                            <option  value="7">HSC (Science)</option>
                                                                            <option selected value="8">HSC (Commerce)</option>
                                                                    </select>
                            </div>

                            <div class="col-md-6">
                                <label><strong>Select Group</strong></label>
                                <select class="form-control" name="subject_id" id="designation">
                                    <option value="11">Group A</option>
                                </select>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-4">
                                <label><strong>Admission Fee</strong></label>
                                <div class="input-group">
                                    <input type="text" id="admisionFee" value="1000" class="form-control input-lg" readonly>
                                    <div class="input-group-append">
                                    <span class="input-group-text">
                                            $
                                            </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label><strong>Monthly Fee</strong></label>
                                <div class="input-group">
                                    <input type="text" id="monthlyFee" value="3000" readonly class="form-control input-lg">
                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label><strong>Discount <small>(Total Of Admission Fee)</small></strong></label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="discount" value="0" name="discount">
                                    <div class="input-group-append">
                                    <span class="input-group-text">
                                        <select name="admission_discount_status" id="type">
                                            <option value="">Type</option>
                                            <option  value="2">%</option>
                                            <option  value="1">$</option>
                                        </select>
                                    </span>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="form-group row">

                            <div class="col-md-4">
                                <label><strong>After Discount Admission Fee</strong></label>
                                <div class="input-group">
                                    <input type="text" id="afterDis"                                                                         value="0"
                                     readonly class="form-control input-lg" >
                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label><strong>Advance</strong></label>
                                <div class="input-group">
                                    <input type="text"  class="form-control input-lg" value="500" id="advance" name="advance">
                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label><strong>Due</strong></label>
                                <div class="input-group">
                                    <input type="text" id="due" readonly value="500" class="form-control input-lg">
                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                    </div>
                                </div>
                            </div>

                        </div>



                    </div>
                </div>

                <div class="tile">
                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Others Information </h4>
                    <div class="tile-body">

                        <div class="form-group">
                            <label> <strong>Fathers Name</strong></label>
                            <input type="text" name="f_name" value="Father Protik" class="form-control input-lg" required>
                        </div>

                        <div class="form-group">
                            <label> <strong>Mothers Name</strong></label>
                            <input type="text" name="m_name" value="Mother Protik" class="form-control input-lg" required>
                        </div>

                        <div class="form-group">
                            <label> <strong>Current Address</strong></label>
                            <textarea type="text" name="c_address" rows="3" class="form-control" >Cards include various options for customizing their backgrounds, borders, and color.</textarea>
                        </div>

                        <div class="form-group">
                            <label> <strong>Permanent Address</strong></label>
                            <textarea type="text" name="p_address" rows="3" class="form-control" >Cards include various options for customizing their backgrounds, borders, and color.</textarea>
                        </div>

                        <div class="form-group">
                            <label> <strong>Guardians Address</strong></label>
                            <textarea type="text" name="guardian_address" rows="3" class="form-control" >Cards include various options for customizing their backgrounds, borders, and color.</textarea>
                        </div>

                        <div class="form-group">
                            <label> <strong>Student's Document <small>(Optional)</small></strong></label>
                            <input type="file" name="b_certificate" class="form-control">

                            <a download href="http://preview.thesoftking.com/thesoftking/itech/assets/images/student/doc/1533389853.jpg">Download Student Document</a>
                        </div>

                    </div>
                </div>

            </div>

            <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </div>
    </form>


    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/generate/pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/popper.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>

    <script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-datepicker.min.js"></script>
    <script>
        $('#demoDate').datepicker({
            format: "yyyy/mm/dd",
            autoclose: true,
            todayHighlight: true
        });

        $('#demoDate1').datepicker({
            format: "yyyy/mm/dd",
            autoclose: true,
            todayHighlight: true
        });
    </script>
    <script>


        $(document).ready(function () {

            var total = $('#afterDis').val();
            var advance = $('#advance').val();

            var due = Number(total) - Number(advance);
            $('#due').val(due);


            $(document).on('change','#department',function(){
                var id = $(this).val();
                $('#discount').val(' ');
                $('#type').val(' ');

                $.ajax({
                    type:"POST",
                    url:"http://preview.thesoftking.com/thesoftking/itech/admin/student/cat/pass",
                    data:{
                        'id' : id,
                        '_token' : "FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb"
                    },
                    success:function(data){
                        $('#designation').html(data.output);
                        $('#admisionFee').val(data.cat_add_fee);
                        $('#monthlyFee').val(data.cat_monthly_fee);
                        $('#afterDis').val(data.cat_add_fee);


                        $(document).on('change','#type',function () {
                            var total = data.cat_add_fee;
                            var type = $(this).val();
                            $('#advance').val(' ');

                            if(type == 1)
                            {
                                if (total > Number($('#discount').val())){
                                    var val = total - Number($('#discount').val());
                                    $('#afterDis').val(val);
                                    return false;
                                }else {
                                    alert('Invalid Amount');
                                    $('#afterDis').val(' ');
                                }

                            }else {
                                var dis = (total*Number($('#discount').val()))/100;
                                var val = total - dis;

                                if (Number(total) >= Number(Math.abs(val))){
                                    $('#afterDis').val(val);
                                    return false;
                                }else {
                                    alert('Invalid Amount');
                                    $('#discount').val(' ');
                                }
                            }

                        });

                        $( "#advance" ).click(function() {
                            $('#advance').val(' ');

                            var total = $('#afterDis').val();

                            $(document).on('keyup', '#advance', function () {

                                console.log($(this).val());

                                if(Number(total) >= $(this).val()){
                                    var due = Number(total) - Number($(this).val());
                                    $('#due').val(due);
                                }else {
                                    alert('Invalid Amount');
                                    $('#advance').val('');
                                    $('#due').val('');
                                };
                            });
                        });

                    }
                });
            });


            $(document).on('change','#type',function () {
                var total = $("#admisionFee").val();
                var type = $(this).val();
                $('#advance').val(' ');

                if(type == 1)
                {
                    if (total > Number($('#discount').val())){
                        var val = total - Number($('#discount').val());
                        $('#afterDis').val(val);
                        return false;
                    }else {
                        alert('Invalid Amount');
                        $('#afterDis').val(' ');
                    }

                }else {
                    var dis = (total*Number($('#discount').val()))/100;
                    var val = total - dis;

                    if (Number(total) >= Number(Math.abs(val))){
                        $('#afterDis').val(val);
                        return false;
                    }else {
                        alert('Invalid Amount');
                        $('#discount').val(' ');
                    }
                }

            });

            $( "#advance" ).click(function() {
                $('#advance').val(' ');

                var total = $('#afterDis').val();

                $(document).on('keyup', '#advance', function () {

                    if(Number(total) >= $(this).val()){
                        var due = Number(total) - Number($(this).val());
                        $('#due').val(due);
                    }else {
                        alert('Invalid Amount');
                        $('#advance').val('');
                        $('#due').val('');
                    };
                });
            });



            var SITE = SITE || {};

            SITE.fileInputs = function() {
                var $this = $(this),
                    $val = $this.val(),
                    valArray = $val.split('\\'),
                    newVal = valArray[valArray.length-1],
                    $button = $this.siblings('.btn'),
                    $fakeFile = $this.siblings('.file-holder');
                if(newVal !== '') {
                    $button.text('Photo Chosen');
                    if($fakeFile.length === 0) {
                        $button.after('<span class="file-holder">' + newVal + '</span>');
                    } else {
                        $fakeFile.text(newVal);
                    }
                }
            };


            $('.file-wrapper input[type=file]').bind('change focus click', SITE.fileInputs);

            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    var tmppath = URL.createObjectURL(event.target.files[0]);

                    reader.onload = function (e) {
                        $('#img-uploaded').attr('src', e.target.result);
                        $('input.img-path').val(tmppath);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $(".uploader").change(function(){
                readURL(this);
            });
        });
    </script>




</body>
</html>