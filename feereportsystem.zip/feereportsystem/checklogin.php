<?php
session_start();
ob_start();
include_once('connection.php');

if(isset($_POST["username"]) or isset($_POST["password"])){

//sleep(1);

$username = $_POST["username"];
$password = $_POST["password"];
$mdpass = md5($password);

$data = mysqli_query($conms,"SELECT * FROM tbl_user WHERE username='".$username."' AND password ='".$mdpass."'") or die("Query Failed");
 if($result = mysqli_num_rows($data) > 0){
	$rs = mysqli_fetch_array($data);
	$uname = $rs['username'];
	$tm = time();
	$si = "$username$tm";
	$sid = md5($si);
	$_SESSION['sid'] = $sid;
	$_SESSION['username'] = $uname;
	//mysqli_query($conms,"UPDATE users SET sid='".$sid."' WHERE email='".$username."'");
	echo "ok"; // log in
}else{
	echo "Incorrect Username or Password";
}  //end else

//		echo json_encode($return_arr); // return value 

exit();
}
?>