<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | Departments</title>
	<?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
 <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i> Department Management</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12">
                        <div class="tile">
                <div class="tile-body">
                    <div class="table-responsive">
                        <div class="caption font-dark" >
                            <i class="icon-settings font-dark"></i>
                            <button id="btn_add" data-toggle="modal" data-target="#myModal" class="btn btn-primary bold"><i class="fa fa-plus"></i> Add New Department</button>
                        </div>
                        <table class="table table-striped table-bordered table-hover order-column" id="sampleTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Department Name</th>
                                <th>Students</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
							<?php
								$sn = 0;
								 $getdept_sql ="SELECT * FROM departments";
								 $getdept_qry = $db->select($getdept_sql);
								 if($getdept_qry){
								 while($getdept_rs = $getdept_qry->fetch_assoc()){
									$sn = $sn + 1;
								?>
                               <tr>
                                   <td><?php echo $sn;?></td>
                                   <td><?php echo $getdept_rs['department'];?></td>
                                   <td><a data-toggle="modal" href="#subject8" class="btn btn-dark">View Classes</a></td>
                                   <td><a class="btn btn-primary" href="#" >Edit</a></td>
                                </tr>

                                <div class="modal fade" id="subject8" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel"> Classes</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                            </div>
                                            <div class="modal-body">
                                                <ul>
													<?php	
														 $getclass_sql ="SELECT * FROM addclass";
														 $getclass_qry = $db->select($getclass_sql);
														 if($getclass_qry){
														 while($getclass_rs = $getclass_qry->fetch_assoc()){
															
													?>
													<li><?php echo $getclass_rs['classname'];?></li>
													<?php } }?>
												</ul>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
							<?php } }?> 
                            <tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> Add New Department</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
            <form id="frmProducts" method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/category" class="form-horizontal">
                    <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">                <div class="modal-body">
                    <div class="form-group error row">
                        <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Department Name:</strong> </label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control has-error bold " id="name" name="name" placeholder="Name" required>
                        </div>
                    </div>

                    <div class="form-group error row">
                        <div class="col-md-6">
                            <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Admission Fee<small>(If Have)</small>:</strong> </label>
                            <div class="input-group">
                                <input type="text" class="form-control input-lg" name="addmission_fee" placeholder="Admission Fee">
                                <div class="input-group-append"><span class="input-group-text">$</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Monthly Fee<small>(If Have)</small>:</strong> </label>
                            <div class="input-group">
                                <input type="text" class="form-control input-lg" name="monthly_fee" placeholder="Monthly Fee">
                                <div class="input-group-append"><span class="input-group-text">$</span>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label class="col-sm-12 control-label bold uppercase"> Group : </label>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="description">
                                    <div class="row">
                                        <div class="col-md-12" id="planDescriptionContainer">
                                            <div class="input-group">
                                                <input name="subject[]" class="form-control margin-top-10" type="text" required placeholder="Group Name">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-danger margin-top-10 delete_desc" type="button"><i class='fa fa-times'></i></button>
                                                </span>
                                            </div>
                                        </div>
                                    </div><br>

                                    <div class="row">
                                        <div class="col-md-12 text-right">
                                            <button id="btnAddDescription" type="button" class="btn btn-sm btn-dark">Add New Group</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                    <input type="hidden" name="status" value="on">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary bold uppercase"><i class="fa fa-send"></i> Save</button>
                </div>
            </form>
            </div>
        </div>

    </div>



    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/generate/pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/popper.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>

    <script>
        $(document).ready(function () {
            $("#btnAddDescription").on('click', function () {
                appendPlanDescField($("#planDescriptionContainer"));
            });

            $(".btnAddDescription2").on('click', function () {
                appendPlanDescField1($(".planDescriptionContainer1"));
            });

            $(document).on('click', '.delete_desc', function () {
                $(this).closest('.input-group').remove();
            });
        });


        function appendPlanDescField(container) {
            container.append(
                '<div class="input-group" style="margin-top: 10px;">\n' +
                '<input name="subject[]" class="form-control margin-top-10" type="text" required placeholder="Group Name">\n' +
                '<span class="input-group-btn">\n' +
                '<button class="btn btn-danger margin-top-10 delete_desc" type="button"><i class=\'fa fa-times\'></i></button>\n' +
                '</span>\n' +
                '</div>'
            );
        }

        function appendPlanDescField1(container) {
            container.append(
                '<div class="input-group" style="margin-top: 10px;">\n' +
                '<input type="hidden" name="deg_id[]">' +
                '<input name="subject[]" class="form-control margin-top-10" type="text" required placeholder="Group Name">\n' +
                '<span class="input-group-btn">\n' +
                '<button class="btn btn-danger margin-top-10 delete_desc" type="button"><i class=\'fa fa-times\'></i></button>\n' +
                '</span>\n' +
                '</div>'
            );
        }

        $(document).ready(function () {
            $(document).on('click','.delete_id',function(e){

                var product_id = $(this).data('id');

                $.ajax({
                    type: "POST",
                    url: "http://preview.thesoftking.com/thesoftking/itech/admin/category/subject",
                    data: {
                        'id':product_id,
                        '_token': "FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb"
                    },

                    success: function (data) {
                        $(".product" + product_id).remove();
                    },
                    error: function (data) {
                        console.log('Error:', data);
                    }
                }).done(function() {
                    swal('Success','Successfully Group Deleted.','success');
                });
            });
        });
    </script>



</body>
</html>