<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<?php
	$pid = $_GET['pid'];
	if(!isset($pid) || $pid == NULL){
		header('Location:students.php');
	}else{
		$gpid = $pid;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | Students Payment Details</title>
	<?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
	<style>
		#mn{
			box-shadow: 0 1px 0 0 red; /* Border bottom */
			box-shadow: 0 -1px 0 0 red; /* Border top */
			box-shadow: -1px 0 0 0 red; /* Border left */
			box-shadow: 1px 0 0 0 red; /* Border right */
		}
		
	</style>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i>Stduent Payment Details</h1>
        </div>
    </div>
     <br/>
	
		 	<div class="row">
			<?php 
						$query ="SELECT * FROM student WHERE id= $gpid";
						$query_run = $db->select($query);
						while($row = $query_run->fetch_assoc()){
							$stdid = $row['id'];
							$dept = $row['dept_id'];
							$class = $row['class_id'];
							
						?>
                <div class="col-md-5" style="background:#fff;border-radius:5px">
				<br/>
					<?php
					 $getdp_sql ="SELECT * FROM departments WHERE dept_id= $dept";
					 $getdp_qry = $db->select($getdp_sql);
					 $getdp_rs = $getdp_qry->fetch_assoc();		 
				?>
				
				<?php
					 $getcl_sql ="SELECT * FROM addclass WHERE classid= $class";
					 $getcl_qry = $db->select($getcl_sql);
					 $getcl_rs = $getcl_qry->fetch_assoc();		 
				?>
                    <h3><?php echo $row['sname'];?></h3>
                    <p><b>Department: <?php echo $getdp_rs['department']?></b></p>
                    <p><b>Class: </b><?php echo $getcl_rs['classname']?></p>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
					<p><center><a href="getstdreport.php?stdrid=<?php echo $stdid;?>" class="btn btn-success btn-block">Print as report</a></center></p>
					
                </div>             
                <div class="col-md-7" style="background:#fff;border-radius:5px;">
                   <br/>
				   <p><b>Fee Items Paid</b></p>
				   <hr/>
				   <table>
				  <?php
					// get an array of items student paid
					$sql = "SELECT * FROM student as std JOIN feerecord as fr WHERE std.dept_id = fr.dept_id AND std.class_id = fr.class_id";
					$res2 = $db->select($sql);
					while ($row = $res2->fetch_assoc()){
						$registration = $row['registration'];
						$exam = $row['exam'];
						$games = $row['games'];
						$library = $row['library'];
						$idcard = $row['idcard'];
						$verification = $row['verification'];
						$prospectus = $row['prospectus'];
						$medical = $row['medical'];
						$technology = $row['technology'];
						$practical = $row['practical'];
						$tuition = $row['tuition'];
						$endowment = $row['endowment'];
						$eed = $row['eed'];
						$siwes = $row['siwes'];
						$accomodation = $row['accomodation'];
						 
						  if($registration == "Registration"){  
							$msg1 = 'checked="checked" disabled';
						 }
						 
						 if($exam == "Exam"){  
							$msg2 = 'checked="checked" disabled';
						 }
						 
						 if($games == "Exercise Books and Writing Materials"){  
							$msg3 = 'checked="checked" disabled';
						 }
						 
						 if($library == "Library"){  
							$msg4 = 'checked="checked" disabled';
						 }
						 
						 if($idcard == "ID CARD"){  
							$msg5 = 'checked="checked" disabled';
						 }
						 
						 if($verification == "Verification"){  
							$msg6 = 'checked="checked" disabled';
						 }
						 
						 if($prospectus == "Prospectus"){  
							$msg7 = 'checked="checked" disabled';
						 }
						 
						 if($medical == "Medical"){  
							$msg8 = 'checked="checked" disabled';
						 }
						 
						 if($technology == "Technology"){  
							$msg9 = 'checked="checked" disabled';
						 }
						 
						 if($practical == "Practical"){  
							$msg10 = 'checked="checked" disabled';
						 }
						 
						 if($tuition == "Tuition"){  
							$msg11 = 'checked="checked" disabled';
						 }
						 
						 if($endowment == "Endowment"){  
							$msg12 = 'checked="checked" disabled';
						 }
						 
						 if($eed == "EED"){  
							$msg13 = 'checked="checked" disabled';
						 }
						 
						 if($siwes == "SIWES"){  
							$msg14 = 'checked="checked" disabled';
						 }
						 
						 if($accomodation == "Accomodation"){  
							$msg15 = 'checked="checked" disabled';
						 }
						 
					}
				  ?>
			<tr>
				<td>
					  <p><input type="checkbox" name="item[]"  id="item" value="Registration" <?php if(isset($msg1)){echo $msg1;}else{echo "";}?>> Registration Fee &nbsp;&nbsp;&nbsp;&nbsp;</p>
						<p><input type="checkbox" name="item[]" id="item" value="Exam" <?php if(isset($msg2)){echo $msg2;}else{echo "";}?>> Exam &nbsp;&nbsp;&nbsp;&nbsp;</p>
						<p><input type="checkbox" name="item[]" id="item" value="Games" <?php if(isset($msg3)){echo $msg3;}else{echo "";}?>> Games&nbsp;&nbsp;&nbsp;&nbsp;</p>
						<p><input type="checkbox" name="item[]" id="item" value="Library" <?php if(isset($msg4)){echo $msg4;}else{echo "";}?>> Library &nbsp;&nbsp;&nbsp;&nbsp;</p>
						<p><input type="checkbox" name="item[]" id="item" value="ID Card" <?php if(isset($msg5)){echo $msg5;}else{echo "";}?>> ID Card&nbsp;&nbsp;&nbsp;&nbsp;</p>
						
				</td>
				<td>
				
		<p><input type="checkbox" name="item[]" id="item" value="Verification" <?php if(isset($msg6)){echo $msg6;}else{echo "";}?>> Verification&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="Prospectus" <?php if(isset($msg7)){echo $msg7;}else{echo "";}?>> Prospectus&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="Medical" <?php if(isset($msg8)){echo $msg8;}else{echo "";}?>> Medical&nbsp;&nbsp;&nbsp;&nbsp;</p>
				<p><input type="checkbox" name="item[]" id="item" value="Technology" <?php if(isset($msg9)){echo $msg9;}else{echo "";}?>> Technology&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="Practical" <?php if(isset($msg10)){echo $msg10;}else{echo "";}?>> Practical&nbsp;&nbsp;&nbsp;&nbsp;</p>
				</td>
				<td>
				<p><input type="checkbox" name="item[]" id="item" value="Tuition" <?php if(isset($msg11)){echo $msg11;}else{echo "";}?>> Tuition&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="Endowment" <?php if(isset($msg11)){echo $msg12;}else{echo "";}?>> Endowment&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="EED" <?php if(isset($msg13)){echo $msg13;}else{echo "";}?>> EED &nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="SIWES" <?php if(isset($msg13)){echo $msg13;}else{echo "";}?>> SIWES &nbsp;&nbsp;&nbsp;&nbsp;</p>
		<p><input type="checkbox" name="item[]" id="item" value="Accomodation" <?php if(isset($msg13)){echo $msg13;}else{echo "";}?>> Accomodation &nbsp;&nbsp;&nbsp;&nbsp;</p>
				</td>
			</tr>
		</table>
				
                </div>
				<?php } ?>
            
			</div>
			
		
</main>
<!-- Essential javascripts for application to work-->
<script src="assets/admin/js/jquery.min.js"></script>
<script src="assets/admin/js/popper.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
<script src="assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script src="assets/admin/js/datatable.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.min.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.bootstrap.js" type="text/javascript"></script>
<script src="assets/admin/js/table-datatables-buttons.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#sampleTable').DataTable( {
		'responsive': true,
        'info': true
		} );
	} );
</script>
<!--<script type="text/javascript">
	$( document ).ready(function() {
	$('#sampleTable').DataTable({
			 "dom": 'lBfrtip',
			"buttons": [
				{
					extend: 'collection',
					text: 'Export',
					buttons: [
						'copy',
						'excel',
						'csv',
						'pdf',
						'print'
					]
				}
			]
	});
	});
</script>-->

<script>
    $(document).on('click','#addPayment', function () {
        $("#PaymentModal").modal('show');
        $("#duu").text($(this).data('due'));
        $("#invoiceId").val($(this).data('id'));

    });
</script>



</body>
</html>