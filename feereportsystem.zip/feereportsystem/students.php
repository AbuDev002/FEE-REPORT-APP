<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | Students</title>
	<?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i> Student List</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12">
            
            <div class="row">
                <div class="col-md-12">
                    <div class="tile">
                        <div class="tile-body">

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <form method="GET" action="sdtdetail_report.php" class="form-horizontal">

                                                <div class="form-group error row">
                                                    <div class="col-md-12">
                                                        <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Search Student:</strong> </label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control input-lg" name="search" placeholder="Search By Matric No." autocomplete="off" required>
                                                            <div class="input-group-append"><span class="input-group-text">
                                                    <i class="fa fa-user"></i>
                                                    </span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <button type="submit" name="stdreport" class="btn btn-primary bold uppercase btn-block"><i class="fa fa-search"></i>Get Fee Report</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <!--<a href="create.php" class="btn btn-primary btn-block btn-lg bold"><i class="fa fa-plus"></i>Add New Student</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
				<?php include_once('stdexcel/upload_file.inc.php');?>
				<?php if(isset($error_msg)){echo $error_msg;}?>
				<table width="100%" border="1"  style="border-collapse:collapse; font-size:12px;" class="table table-bordered">
				<tr>
						<td></td>
						<td>
							<form action="students.php" method="POST" enctype="multipart/form-data">
								<table class="table table-bordered table-responsive">
									<tr>
										<td colspan="8" align="center"><b>Upload Students List</b> &nbsp; &nbsp;<font class="text-warning">Only .csv Format</font></td>
									</tr>
									<tr>
										<td>
											<input type='file' name='upload1'>
											<!--<input type='file' name='upload2'>-->			
										</td>
										<td style="padding:10px;width:200px;">
												<select  class="form-control" name="school"  onchange='if(this.value !=0){this.form.submit();}' style="width:100%;">
													<option value="">--Department--</option>
													<?php 
														$query ="SELECT * FROM departments";
														$query_run = $db->select($query);
														//$result =mysqli_num_rows($query_run);
														while($row = $query_run->fetch_assoc()){
															$branch_id = $row['dept_id'];
															$branch_name = $row['department'];
															if (@$_POST['school'] == $branch_id) {

																	echo "<option value=\"".$branch_id."\" selected='selected'>".$branch_name."</option>"; 
																} else {
																	echo "<option value=\"".$branch_id."\">".$branch_name."</option>";       
																}
														?>
													

												  <?php } ?>
												</select>
											</td>
											<!-- option -->
											<td style="padding:10px;">
												<select class="form-control" name="course_option" style="width:100%;">
													<option value="">--Option--</option>
													<?php 
														$query ="SELECT * FROM course_option";
														$query_run = $db->select($query);
														//$result =mysqli_num_rows($query_run);
														while($row = $query_run->fetch_assoc()){
															$option_id = $row['id'];
															$option_name = $row['course_option'];
															if (@$_POST['course_option'] == $option_id) {

																	echo "<option value=\"".$option_id."\" selected='selected'>".$option_name."</option>"; 
																} else {
																	echo "<option value=\"".$option_id."\">".$option_name."</option>";       
																}
														?>
													

												  <?php } ?>
							
												</select>
											</td>

											<td style="padding:10px;">
												<select class="form-control" name="class" style="width:100%;">
													<option value="">--Class--</option>
													<?php 
														
														$query ="SELECT * FROM addclass";
														$query_run =$db->select($query);
														//$result =mysqli_num_rows($query_run);
														while($row = $query_run ->fetch_assoc()){
															$class_id = $row['classid'];
															$class_name = $row['classname'];
															$str = $row['stream'];
															if ($_POST['class'] == $class_id) {

																	echo "<option value=\"".$class_id."\" selected='selected'>".$class_name." ".$str."</option>"; 
																} else {
																	echo "<option value=\"".$class_id."\">".$class_name." ".$str."</option>";       
																}
														?>
													

												  <?php } ?>
												</select>
											</td>
											
											<td style="padding:10px;">
												<select class="form-control" name="session"  style="width:100%;">
													<option value="">--Session--</option>
													<?php 
														$query ="SELECT * FROM tbl_sessions";
														$query_run = $db->select($query);
														//$result =mysqli_num_rows($query_run);
														while($row = $query_run->fetch_assoc()){
															$sess_id = $row['sess_id'];
															$sess_name = $row['sess_name'];
															if (@$_POST['session'] == $sess_name) {

																	echo "<option value=\"".$sess_name."\" selected='selected'>".$sess_name."</option>"; 
																} else {
																	echo "<option value=\"".$sess_name."\">".$sess_name."</option>";       
																}
														?>
													

												  <?php } ?>
												</select>
											</td>
											<td><button class="btn btn-success" type="submit" name="btnUploadStudent">Upload Students</button></td>
									</tr>
								</table>

							</form>

						</td>
						<!-- <td><a href="add_subject.php">Add Subject</a></td> -->
						</tr>
				</table>
           <div class="row">
               <div class="col-md-12">
                   <div class="tile">
                       <div class="tile-body">

                           
                           <div class="table-responsive">
                               <table class="table table-striped table-bordered table-hover order-column datatable" id="sampleTable">
                                   <thead>
									   <tr>
										   <th>Matric No.</th>
										   <th>Name</th>
										   <th>Department</th>
										   <th>Current Status</th>
										   <!--<th>Action</th>
										   <th></th>-->
									   </tr>
                                   </thead>
                                   <tbody>
                                        <?php
										 $getstudents_sql ="SELECT * FROM student";
										 $getstudents_qry = $db->select($getstudents_sql);
										 if($getstudents_qry){
										 while($getstudent_rs = $getstudents_qry->fetch_assoc()){
											$dept =  $getstudent_rs['dept_id'];
										?>
										<tr>
                                           <td><?php echo $getstudent_rs['admin_no']?></td>
                                           <td><?php echo $getstudent_rs['sname']?></td>
                                           <td><?php 
												 $getdept_sql ="SELECT * FROM departments WHERE dept_id =$dept";
												 $getdept_qry = $db->select($getdept_sql);
												 $getdept_rs = $getdept_qry->fetch_assoc();
												 echo $getdept_rs['department'];
										   ?></td>
                                           <td>
											<span class="badge badge-success">Active</span>
										   </td>
										   <!--<td><a href="#" class="btn btn-dark">View/Edit Profile</a></td>
										   <td><a href="<?php //echo $getstudent_rs['id']?>"  class="btn btn-danger">View Payment Details</a></td>--> 
											<!--payment_details.php-->
									   </tr>
										<?php }} ?>                                  
                                       </tbody>
                               </table>
                               
                           </div>
                       </div>
                   </div>
               </div>

           </div>
        </div>
    </div>

    <div class="modal fade" id="PaymentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> Add Payment</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form id="frmProducts" method="post" action="payment" class="form-horizontal">
                    <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">                    <input type="hidden" name="id" id="invoiceId">
                    <div class="modal-body">
                        <div class="col-md-12 text-center">
                            <h4 style="color: red">Due: <span id="duu"></span> N </h4>
                        </div>

                        <div class="form-group error row">

                            <div class="col-md-12">
                                <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Amount :</strong> </label>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" name="amount" placeholder="Amount" required>
                                    <div class="input-group-append"><span class="input-group-text">
                                        N
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary bold uppercase"><i class="fa fa-send"></i> Add Payment</button>
                    </div>
                </form>
            </div>
        </div>

    </div>


    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="assets/admin/js/jquery.min.js"></script>
<script src="assets/admin/js/popper.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
<script src="assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script src="assets/admin/js/datatable.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.min.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.bootstrap.js" type="text/javascript"></script>
<script src="assets/admin/js/table-datatables-buttons.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#sampleTable').DataTable( {
		'responsive': true,
        'info': true
		} );
	} );
</script>
<!--<script type="text/javascript">
	$( document ).ready(function() {
	$('#sampleTable').DataTable({
			 "dom": 'lBfrtip',
			"buttons": [
				{
					extend: 'collection',
					text: 'Export',
					buttons: [
						'copy',
						'excel',
						'csv',
						'pdf',
						'print'
					]
				}
			]
	});
	});
</script>-->

<script>
    $(document).on('click','#addPayment', function () {
        $("#PaymentModal").modal('show');
        $("#duu").text($(this).data('due'));
        $("#invoiceId").val($(this).data('id'));

    });
</script>



</body>
</html>