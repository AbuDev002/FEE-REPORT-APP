<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | DashBoard</title>
    <?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
 <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i> DashBoard</h1>
        </div>
    </div>
    <?php include_once('php/upexcel/upload_file.inc.php');?>
	<?php if(isset($error_msg)){echo $error_msg;}?>
	<table width="100%" border="1"  style="border-collapse:collapse; font-size:12px;" class="table table-bordered record">
				<tr>
						<td></td>
						<td>
							<form action="dashboard.php" method="POST" enctype="multipart/form-data">
								<table class="table table-bordered table-responsive">
									<tr>
										<td colspan="8" align="center"><b>Upload Schedule of Fees</b> &nbsp; &nbsp;<font class="text-warning">Only .csv Format</font></td>
									</tr>
									<tr>
										<td>
											<input type='file' name='upload1'>
											<!--<input type='file' name='upload2'>-->			
										</td>
										<td style="padding:10px;">
												<select  name="fee_session"  style="width:100%;">
													<option value="">--Select Academic Session--</option>
													<?php
													 $getdsess_sql ="SELECT * FROM tbl_sessions";
													 $getsess_qry = $db->select($getdsess_sql);
													 if($getsess_qry){
													 while($getsess_rs = $getsess_qry->fetch_assoc()){
													
													?>
													<option value="<?php echo $getsess_rs['sess_name'];?>"><?php echo $getsess_rs['sess_name'];?></option>
													 <?php } }?>
													
												</select>
											</td>
											<td style="padding:10px;">
												<select name="fee_stream" style="width:100%;">
													<option value="">--Select Stream--</option>
													<option value="A">Stream A</option>
													<option value="B">Stream B</option>
													
												</select>
											</td>
						
										<td>
										<button type="submit" name="btnScheduleOfFees">Upload Schedule of Fees</button>
										</td>
									</tr>
								</table>

							</form>

						</td>
						<!-- <td><a href="add_subject.php">Add Subject</a></td> -->
						</tr>
				</table>

    <div class="row">
        <div class="col-md-4">
            <a href="student" style="text-decoration: none">
                <div class="widget-small primary"><i class="icon fa fa-home fa-3x"></i>
                    <div class="info">
                        <h4>Schools</h4>
                       <?php
						 $getdsch_sql ="SELECT count(*) as nos FROM schools";
						 $getsch_qry = $db->select($getdsch_sql);
						 if($getsch_qry){
						 while($getsch_rs = $getsch_qry->fetch_assoc()){
						
						?>
						<p><b><?php echo $getsch_rs['nos'];?></b></p>
						 <?php } }?>
                    </div>
                </div>
            </a>
        </div>


        <div class="col-md-4">
            <a href="category" style="text-decoration: none">
            <div class="widget-small info"><i class="icon fa fa-briefcase fa-3x"></i>
                <div class="info">
                    <h4>Departments</h4>
					<?php
					 $getdept_sql ="SELECT count(*) as nod FROM departments";
					 $getdept_qry = $db->select($getdept_sql);
					 if($getdept_qry){
					 while($getdept_rs = $getdept_qry->fetch_assoc()){
					
					?>
                    <p><b><?php echo $getdept_rs['nod'];?></b></p>
					 <?php } }?>
                </div>
            </div>
            </a>
        </div>
		<div class="col-md-4">
            <a href="students.php" style="text-decoration: none">
                <div class="widget-small primary"><i class="icon fa fa-users fa-3x"></i>
                    <div class="info">
                        <h4>Students</h4>
						<?php
					 $getstudent_sql ="SELECT count(*) as nos FROM student";
					 $getstudent_qry = $db->select($getstudent_sql);
					 if($getstudent_qry){
					 while($getstudent_rs = $getstudent_qry->fetch_assoc()){
					
					?>
                        <p><b><?php echo $getstudent_rs['nos'];?></b></p>
					<?php } }?>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="assets/admin/js/popper.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
<script src="assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="assets/admin/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="assets/admin/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>

<script src="assets/admin/js/rapheal.js"></script>
<script src="assets/admin/js/morrisline.js"></script>


</body>
</html>