   <aside class="app-sidebar">
    <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" class="img-circle" src="assets/images/logo/polylogo.jpg" alt="User Image">
        <div>
            <p class="app-sidebar__user-name">Admin </p>
            <p class="app-sidebar__user-designation">FPTB Administrator</p>
        </div>
    </div>
    <ul class="app-menu">
        <li><a class="app-menu__item  active " href="dashboard.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

        <li><a class="app-menu__item " href="departments.php"><i class="app-menu__icon fa fa-sitemap"></i><span class="app-menu__label">Manage Department</span></a></li>

        <li><a class="app-menu__item " href="students.php"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Student</span></a></li>
        <!--<li>
            <a class="app-menu__item" href="schedule_fees.php"><i class="app-menu__icon fa fa-money"></i><span class="app-menu__label">Schedule of Fees</span></a>
        </li>-->
		 <li>
            <a class="app-menu__item" href="fees_reports.php"><i class="app-menu__icon fa fa-money"></i><span class="app-menu__label">Fee Reports</span></a>
        </li>
	</ul>
</aside>