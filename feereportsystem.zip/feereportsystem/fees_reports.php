<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | Students</title>
	<?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-report"></i>Fees Report</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12"> 
            <div class="row">
                <div class="col-md-12">
                    <div class="tile">
                        <div class="tile-body">
								<div class="row">
									<div class="col-md-3"></div>
									<div class="col-md-6">
										<form action="studentsfee_report.php" method="get">
											<label for=""><strong>Department</strong></label>
                                            <select name="department" class="form-control" required>
												<option value="">--Select Department--</option>
												<?php
												 $getdept_sql ="SELECT * FROM departments";
												 $getdept_qry = $db->select($getdept_sql);
												 if($getdept_qry){
												 while($getdept_rs = $getdept_qry->fetch_assoc()){
													
												?>
													<option value="<?php echo $getdept_rs['dept_id'];?>"><?php echo $getdept_rs['department'];?></option>
												<?php }}?>
											</select>
                                            <hr>
											<label for=""><strong>Class</strong></label>
											<select name="class" class="form-control" required>
												<option value="">--Select Class--</option>
												<?php
												 $getclass_sql ="SELECT * FROM addclass";
												 $getclass_qry = $db->select($getclass_sql);
												 if($getclass_qry){
												 while($getclass_rs = $getclass_qry->fetch_assoc()){
													
												?>
													<option value="<?php echo $getclass_rs['classid'];?>"><?php echo $getclass_rs['classname'];?></option>
												<?php }}?>
											</select>
                                            <hr>
                                            <label for=""><strong>Stream</strong></label>
                                            <select name="stream" class="form-control" required>
                                                <option value="">--Select Stream--</option>
                                                <?php
                                                 $getstream_sql ="SELECT * FROM stream";
                                                 $getstream_qry = $db->select($getstream_sql);
                                                 if($getstream_qry){
                                                 while($getstream_rs = $getstream_qry->fetch_assoc()){
                                                    
                                                ?>
                                                    <option value="<?php echo $getstream_rs['stream_id'];?>"><?php echo $getstream_rs['stream_name'];?></option>
                                                <?php }}?>
                                            </select>
											<br/>
											<p><button class="btn btn-success" type="submit" name="thereport">Get Report</button></p>
										</form>
									</div>
									<div class="col-md-3"></div>
								</div>
								
								
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="PaymentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> Add Payment</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form id="frmProducts" method="post" action="payment" class="form-horizontal">
                    <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">                    <input type="hidden" name="id" id="invoiceId">
                    <div class="modal-body">
                        <div class="col-md-12 text-center">
                            <h4 style="color: red">Due: <span id="duu"></span> $ </h4>
                        </div>

                        <div class="form-group error row">

                            <div class="col-md-12">
                                <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Amount :</strong> </label>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" name="amount" placeholder="Amount" required>
                                    <div class="input-group-append"><span class="input-group-text">
                                        N
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary bold uppercase"><i class="fa fa-send"></i> Add Payment</button>
                    </div>
                </form>
            </div>
        </div>

    </div>


    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="assets/admin/js/jquery.min.js"></script>
<script src="assets/admin/js/popper.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
<script src="assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script src="assets/admin/js/datatable.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.min.js" type="text/javascript"></script>
<script src="assets/admin/js/datatables.bootstrap.js" type="text/javascript"></script>
<script src="assets/admin/js/table-datatables-buttons.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#sampleTable').DataTable( {
		'responsive': true,
        'info': true
		} );
	} );
</script>
<!--<script type="text/javascript">
	$( document ).ready(function() {
	$('#sampleTable').DataTable({
			 "dom": 'lBfrtip',
			"buttons": [
				{
					extend: 'collection',
					text: 'Export',
					buttons: [
						'copy',
						'excel',
						'csv',
						'pdf',
						'print'
					]
				}
			]
	});
	});
</script>-->

<script>
    $(document).on('click','#addPayment', function () {
        $("#PaymentModal").modal('show');
        $("#duu").text($(this).data('due'));
        $("#invoiceId").val($(this).data('id'));

    });
</script>



</body>
</html>