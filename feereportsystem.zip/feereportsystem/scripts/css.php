<!--The Css for the Application-->
<link rel="icon" type="image/png" href="assets/images/logo/fav.jpg" />
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="assets/admin/css/font-awesome.min.css">
	
    <link href="assets/admin/css/bootstrap-toggle.min.css" rel="stylesheet">
    <link href="assets/admin/css/bootstrap-fileinput.css" rel="stylesheet">
    <link href="assets/admin/css/toastr.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/admin/css/table.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="assets/admin/css/custom.css">
    <link rel="stylesheet" type="text/css" href="assets/admin/css/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="assets/admin/css/datatables.bootstrap.css">

    <script src="assets/admin/js/sweetalert.js"></script>
    <link rel="stylesheet" href="assets/admin/css/sweetalert.css">
	<style>
        a.app-header__logo {
            font-size: 20px;
        }

        .app-title{
            background-color:white;
        }
		
		 rect:nth-child(even){
            fill: #8e44ad;
        }
        rect:nth-child(odd){
            fill: #2980b9;
        }
		 button#btn_add {
            margin-bottom: 10px;
        }
		
		 .card-image {
            position: relative;
            overflow: hidden;
        }

        .card-image .ribon {
            position: absolute;
            right: -30px;
            top: 10px;
            display: inline-block;
            background-color: #f88;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 700;
            width: 100px;
            color: #fff;
            text-transform: uppercase;
            transform: rotate(48deg);
            height: 25px;
            line-height: 25px;
            text-align: center;
        }
		.box {
            background-color: #fff;
            border: 1px solid #ddd;
            display: block;
            max-width: 30em;
            margin: 0 auto;
            border-radius: 4px;
        }
        .box header {
            border-bottom: 1px solid #ddd;
            padding: 0.5em 1em;
            margin-bottom: 1em;
        }
        .box .content {
            padding: 1em;
        }

        .left, .right {
            display: table-cell;
            vertical-align: middle;
        }

        .left {
            width: 6em;
            min-width: 6em;
            padding-right: 1em;
        }
        .left img {
            width: 100%;
        }

        .img-holder {
            display: block;
            vertical-align: middle;
            width: 2em;
            height: 2em;
        }
        .img-holder img {
            width: 100%;
            max-width: 100%;
        }

        .file-wrapper {
            cursor: pointer;
            display: inline-block;
            overflow: hidden;
            position: relative;
        }
        .file-wrapper:hover .btn {
            background-color: #33adff !important;
        }

        .file-wrapper input {
            cursor: pointer;
            font-size: 100px;
            height: 100%;
            filter: alpha(opacity=1);
            -moz-opacity: 0.01;
            opacity: 0.01;
            position: absolute;
            right: 0;
            top: 0;
            z-index: 9;
        }
        span.file-holder {
            display: none;
        }
    </style>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
       
