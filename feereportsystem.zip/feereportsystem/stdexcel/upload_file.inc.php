<?php
		$error_msg ="";
	if(isset($_POST['btnUploadStudent'])){
		$std_school = $_POST['school'];
		$course_option = $_POST['course_option'];
		$std_class = $_POST['class'];
		//$std_stream = $_POST['stream'];
		$std_session = $_POST['session'];
		//$tution_fee = mysqli_real_escape_string($db->link,$_POST['tution_fee']);
		//$advancefees = mysqli_real_escape_string($db->link,$_POST['advance_fee']);
		//$balance = $tution_fee-$advancefees;
		@$file1 = $_FILES['upload1'] ['tmp_name'];
		//$file2 = $_FILES['upload2'] ['tmp_name'];
	
		if($file1){
		$handle = fopen($file1,"r");
		
		while(($fileop = fgetcsv($handle,1000,",")) !== false){
				//$s_n = $fileop[0];
				$adms_no = $fileop[1];
				$surname = $fileop[2];
				$firstname = $fileop[3];
				$feepayed = $fileop[4];
				$paymenttype = $fileop[5];
				$sname = $surname.' '.$firstname;
				
				
			$query = $db->insert("INSERT INTO student (admin_no,sname,dept_id,option_id,class_id,amount_payed,payment_type,joindate) VALUES('".mysqli_real_escape_string($db->link,$adms_no)."','".mysqli_real_escape_string($db->link,$sname)."',".$std_school.",".$course_option.",".$std_class.",'".mysqli_real_escape_string($db->link,$feepayed)."','".mysqli_real_escape_string($db->link,$paymenttype)."','".$std_session."')") or die('Upload failed');
		
		}
		
			if($query){
					$error_msg ='<p class="alert alert-success">Students Uploaded</p>';
			
			}
		}else{
				$error_msg ='<p class="alert alert-warning">Please select your students list</>';
		}
	}


?>