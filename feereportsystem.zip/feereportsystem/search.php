
<!DOCTYPE html>
<html lang="en">
<head>
    <title>iTech | Expense Report Search</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://preview.thesoftking.com/thesoftking/itech/assets/images/logo/favicon.png" />
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/font-awesome.min.css">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/bootstrap-toggle.min.css" rel="stylesheet">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/bootstrap-fileinput.css" rel="stylesheet">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/toastr.min.css" rel="stylesheet" type="text/css"/>
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/table.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/custom.css">

    <script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/sweetalert.js"></script>
    <link rel="stylesheet" href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/css/sweetalert.css">
    <link href="http://preview.thesoftking.com/thesoftking/itech/assets/admin/color.php?color=2ecc71" rel="stylesheet">
    <style>
        a.app-header__logo {
            font-size: 20px;
        }

        .app-title{
            background-color:white;
        }
    </style>
    
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<header class="app-header"><a class="app-header__logo" href="http://preview.thesoftking.com/thesoftking/itech">iTech</a>
    <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
    <!-- Navbar Right Menu-->
    <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">admin <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/change-password"><i class="fa fa-cog fa-lg"></i> Password Settings</a></li>
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/profile"><i class="fa fa-user fa-lg"></i> Profile</a></li>
                <li><a class="dropdown-item" href="http://preview.thesoftking.com/thesoftking/itech/admin/logout"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</header>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
    <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" class="img-circle" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/img/admin_1531922370.jpg" alt="User Image">
        <div>
            <p class="app-sidebar__user-name">Admin </p>
            <p class="app-sidebar__user-designation">admin</p>
        </div>
    </div>
    <ul class="app-menu">
        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/category"><i class="app-menu__icon fa fa-sitemap"></i><span class="app-menu__label">Manage Department</span></a></li>

        <li><a class="app-menu__item " href="http://preview.thesoftking.com/thesoftking/itech/admin/student"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Student</span></a></li>


        <li class="treeview ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-money"></i><span class="app-menu__label">Payment Management </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/create/invoice"><i class="icon fa fa-hand-o-right"></i> Due Monthly Payment </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/payment/detail"><i class="icon fa fa-hand-o-right"></i> Student Payment Reports </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/income"><i class="icon fa fa-hand-o-right"></i> Income Panel </a></li>
            </ul>
        </li>

        <li class="treeview  is-expanded
                            ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-credit-card-alt"></i><span class="app-menu__label">Expense Management </span><i class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/expense"><i class="icon fa fa-plus-circle"></i> Create Expense </a></li>
                <li><a class="treeview-item  active " href="http://preview.thesoftking.com/thesoftking/itech/admin/expense/report/search"><i class="icon fa fa-list-alt"></i> Expense Reports </a></li>
            </ul>
        </li>




        <li class="treeview ">
            <a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cogs"></i><span class="app-menu__label">Settings</span><i class="treeview-indicator fa fa-angle-right"></i>
            </a>
            <ul class="treeview-menu">
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/general-settings"><i class="icon fa fa-cogs"></i> General Setting </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/manage-logo"><i class="icon fa fa-photo"></i> Logo & favicon </a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/template"><i class="icon fa fa-envelope"></i> Email Setting</a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/sms-api"><i class="icon fa fa-mobile"></i> SMS Setting</a></li>
                <li><a class="treeview-item " href="http://preview.thesoftking.com/thesoftking/itech/admin/contact-setting"><i class="icon fa fa-phone"></i> Contact Setting </a></li>
            </ul>
        </li>

        <li><a class="app-menu__item" href="#genInv" data-toggle="modal" ><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">Generate Invoice</span></a></li>
    </ul>
</aside><main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i> Expense Report Search</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12">
            
                <div class="tile">
                    <h5 class="tile-title text-center">Search Expend History With Date</h5>
                    <div class="row">
                        <div class="col-md-8 offset-2">
                            <div class="card">
                                <div class="card-body">
                                    <form method="GET" action="http://preview.thesoftking.com/thesoftking/itech/admin/expense/search/result" class="form-horizontal">


                                        <div class="form-group error row">
                                            <div class="col-md-6">
                                                <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Select Start Date:</strong> </label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control input-lg" name="start_date" id="demoDate" placeholder="Start Date">
                                                    <div class="input-group-append"><span class="input-group-text">
                                                    <i class="fa fa-calendar"></i>
                                                    </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Select End Date:</strong> </label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control input-lg" name="end_date" id="demoDate1" placeholder="End Date">
                                                    <div class="input-group-append"><span class="input-group-text">
                                                    <i class="fa fa-calendar"></i>
                                                    </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <button type="submit" class="btn btn-primary bold uppercase btn-block"><i class="fa fa-search"></i> Search</button>

                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>


        </div>
    </div>




    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/generate/pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/popper.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>

    <script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-datepicker.min.js"></script>
    <script>
        $('#demoDate').datepicker({
            format: "yyyy-mm-dd",
            autoclose: true,
            todayHighlight: true
        });

        $('#demoDate1').datepicker({
            format: "yyyy-mm-dd",
            autoclose: true,
            todayHighlight: true
        });

    </script>

    <script>
        $(document).ready(function () {

            $(document).on('change','#department',function(){
                var id = $(this).val();

                $('#type').val(' ');

                $.ajax({
                    type:"POST",
                    url:"http://preview.thesoftking.com/thesoftking/itech/admin/student/cat/pass",
                    data:{
                        'id' : id,
                        '_token' : "FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb"
                    },
                    success:function(data){
                        $('#designation').html(data.output);
                    }
                });
            });
        });
    </script>



</body>
</html>