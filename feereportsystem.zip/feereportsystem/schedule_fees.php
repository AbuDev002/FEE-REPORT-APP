<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>FPTB Fees Report | Schedule of Fees</title>
	<?php include_once('scripts/meta.php');?>
    <?php include_once('scripts/css.php');?>
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include_once('incs/header.php');?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
  <?php include_once('incs/sidebar.php');?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-hand-o-right"></i>All Schedule of Fees</h1>
        </div>
    </div>
        <div class="row">
        <div class="col-md-12">
            
            <div class="row">
                <div class="col-md-12">
                    <div class="tile">
                        <div class="tile-body">

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-body">
											<?php include_once('php/upexcel/upload_file.inc.php');?>
	<?php if(isset($error_msg)){echo $error_msg;}?>
	<table width="100%" border="1"  style="border-collapse:collapse; font-size:12px;" class="table table-bordered record">
				<tr>
						<td></td>
						<td>
							<form action="" method="POST" enctype="multipart/form-data">
								<table class="table table-bordered table-responsive">
									<tr>
										<td colspan="8" align="center"><b>Upload Schedule of Fees</b> &nbsp; &nbsp;<font class="text-warning">Only .csv Format</font></td>
									</tr>
									<tr>
										<td>
											<input type='file' name='upload1'>
											<!--<input type='file' name='upload2'>-->			
										</td>
										<td style="padding:10px;">
												<select  name="fee_session"  style="width:100%;">
													<option value="">--Select Academic Session--</option>
													<?php
													 $getdsess_sql ="SELECT * FROM tbl_sessions";
													 $getsess_qry = $db->select($getdsess_sql);
													 if($getsess_qry){
													 while($getsess_rs = $getsess_qry->fetch_assoc()){
													
													?>
													<option value="<?php echo $getsess_rs['sess_name'];?>"><?php echo $getsess_rs['sess_name'];?></option>
													 <?php } }?>
													
												</select>
											</td>
											<td style="padding:10px;">
												<select name="fee_stream" style="width:100%;">
													<option value="">--Select Stream--</option>
													<option value="A">Stream A</option>
													<option value="B">Stream B</option>
													
												</select>
											</td>
						
										<td>
										<button type="submit" name="btnScheduleOfFees">Upload Schedule of Fees</button>
										</td>
									</tr>
								</table>

							</form>

						</td>
						<!-- <td><a href="add_subject.php">Add Subject</a></td> -->
						</tr>
				</table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

           <div class="row">
               <div class="col-md-12">
                   <div class="tile">
                       <div class="tile-body">

                           
                           <div class="table-responsive">
                             <table class="table table-striped table-bordered table-hover order-column" id="sampleTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Department Name</th>
                                <th>Admission Fee</th>
                                <th>Classes</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
							<?php
								$sn = 0;
								 $getdfeerec_sql ="SELECT * FROM feerecord";
								 $getfeerec_qry = $db->select($getdfeerec_sql);
								 if($getfeerec_qry){
								 while($getfeerec_rs = $getfeerec_qry->fetch_assoc()){
									$sn = $sn + 1;
								?>
								
                               <tr>
                                   <td><?php echo $sn;?></td>
                                   <td><?php echo $getfeerec_rs['fee_type'];?></td>
                                   <td></td>
                                   <td><a data-toggle="modal" href="#subject8" class="btn btn-dark">View Classes</a></td>
                                   <td><label class="badge  badge-success"> Active </label></td>
                                   <td><a class="btn btn-primary" href="http://preview.thesoftking.com/thesoftking/itech/admin/category/8/edit" >Edit</a></td>
                                </tr>

                                <div class="modal fade" id="subject8" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel"><?php echo $getfeerec_rs['fee_type']?></h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                            </div>
                                            <div class="modal-body">
                                                <ol>
                                                </ol>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } }?>                            
                            <tbody>
                        </table>
                               
                           </div>
                       </div>
                   </div>
               </div>

           </div>
        </div>
    </div>

    <div class="modal fade" id="PaymentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> Add Payment</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <form id="frmProducts" method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/add/payment" class="form-horizontal">
                    <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">                    <input type="hidden" name="id" id="invoiceId">
                    <div class="modal-body">
                        <div class="col-md-12 text-center">
                            <h4 style="color: red">Due: <span id="duu"></span> $ </h4>
                        </div>

                        <div class="form-group error row">

                            <div class="col-md-12">
                                <label for="inputName" class="col-sm-12 control-label bold uppercase"><strong>Amount :</strong> </label>
                                <div class="input-group">
                                    <input type="text" class="form-control input-lg" name="amount" placeholder="Amount" required>
                                    <div class="input-group-append"><span class="input-group-text">
                                        $
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary bold uppercase"><i class="fa fa-send"></i> Add Payment</button>
                    </div>
                </form>
            </div>
        </div>

    </div>


    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="http://preview.thesoftking.com/thesoftking/itech/admin/generate/pay" >
                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                        <input type="hidden" name="id" id="deleteID">

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



</main>
<!-- Essential javascripts for application to work-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/popper.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-toggle.min.js"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>

<script>
    $(document).on('click','#addPayment', function () {
        $("#PaymentModal").modal('show');
        $("#duu").text($(this).data('due'));
        $("#invoiceId").val($(this).data('id'));

    });
</script>



</body>
</html>