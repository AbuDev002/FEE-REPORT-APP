-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 24, 2022 at 11:26 AM
-- Server version: 10.3.34-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fptbadmin_dbfptbportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_depts`
--

CREATE TABLE `tbl_depts` (
  `id` int(12) NOT NULL,
  `sch_id` varchar(12) NOT NULL,
  `dept_name` varchar(50) NOT NULL,
  `dept_code` varchar(10) DEFAULT NULL,
  `cw_email` varchar(150) NOT NULL,
  `hod_email` varchar(200) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_depts`
--

INSERT INTO `tbl_depts` (`id`, `sch_id`, `dept_name`, `dept_code`, `cw_email`, `hod_email`, `active`) VALUES
(1, '1', 'COMPUTER SCIENCE', 'COMP', 'examofficer.cs@fptb.edu.ng', '', 1),
(2, '1', 'FOOD SCIENCE AND TECHNOLOGY', 'FST', 'examofficer.fst@fptb.edu.ng', '', 1),
(3, '1', 'SCIENCE LABORATORY TECHNOLOGY', 'SLAB', 'examofficer.slt@fptb.edu.ng', '', 1),
(4, '1', 'PHARMACEUTICAL TECHNOLOGY', 'PHAM', '', '', 0),
(5, '1', 'HOSPITALITY MANAGEMENT', 'HMT', 'examofficer.hmt@fptb.edu.ng', '', 1),
(6, '2', 'MECHANICAL ENGINEERING', 'MECH', 'examofficer.mec@fptb.edu.ng', '', 1),
(7, '2', 'CIVIL ENGINEERING TECHNOLOGY', 'CVET', 'examofficer.cet@fptb.edu.ng', '', 1),
(8, '2', 'ELECTRICAL ELECTRONICS ENGINEERING', 'EEET', 'examofficer.eeet@fptb.edu.ng', '', 1),
(9, '2', 'MECHATRONIC ENGINEERING', 'MTET', 'examofficer.mec@fptb.edu.ng', '', 0),
(10, '2', 'AGRICULTURE AND BIO-ENVIRONMENTAL TECHNOLOGY', 'ABE', 'examofficer.abe@fptb.edu.ng', '', 1),
(11, '3', 'ARCHITECHTURAL TECHNOLOGY', 'ARCH', 'examofficer.arc@fptb.edu.ng', '', 1),
(12, '3', 'BUILDING TECHNOLOGY', 'BLD', 'examofficer.bld@fptb.edu.ng', '', 1),
(13, '3', 'ESTATE MANAGEMENT TECHNOLOGY', 'ESTM', 'examofficer.estm@fptb.edu.ng', '', 1),
(14, '3', 'QUANTITY SURVEY', 'QSVY', 'examofficer.qs@fptb.edu.ng', '', 1),
(15, '3', 'SURVEY AND GEO-INFORMATICS', 'SUGI', 'examofficer.dsug@fptb.edu.ng', '', 1),
(16, '4', 'AGRICULTURAL TECHNOLOGY', 'AGT', 'examofficer.agt@fptb.edu.ng', '', 1),
(17, '5', 'ACCOUNTANCY', 'ACCT', 'examofficer.acct@fptb.edu.ng', '', 1),
(18, '5', 'BANKING AND FINANCE', 'BFN', 'examofficer.bfn@fptb.edu.ng', '', 1),
(19, '5', 'BUSINESS ADMINISTRATION AND MANAGEMENT', 'BAMG', 'examofficer.bam@fptb.edu.ng', '', 1),
(20, '5', 'MARKETING', 'MKT', 'examofficer.mkt@fptb.edu.ng', '', 1),
(21, '5', 'OFFICE TECHNOLOGY AND MANAGEMENT', 'OTM', 'examofficer.otm@fptb.edu.ng', '', 1),
(22, '6', 'GENERAL STUDIES', 'GNS', '', '', 0),
(23, '1', 'MATHS AND STATISTICS', 'MSTA', 'examofficer.mst@fptb.edu.ng', '', 1),
(24, '6', 'MASS COMMUNICATION', 'MACO', 'examofficer.maco@fptb.edu.ng', '', 1),
(25, '6', 'BASIC STUDIES', 'BAST', '', '', 0),
(26, '5', 'PUBLIC ADMINISTRATION', 'PAMG', 'examofficer.pad@fptb.edu.ng', '', 1),
(27, '6', 'CRIME MANAGEMENT AND CONTROL', 'CMGC', 'examofficer.cm@fptb.edu.ng', '', 0),
(28, '1', 'NUTRITION AND DIETETICS', 'NUD', 'examofficer.nud@fptb.edu.ng', '', 1),
(29, '4', 'FORESTRY TECHNOLOGY', 'FOT', 'examofficer.fot@fptb.edu.ng', '', 1),
(31, '4', 'ANIMAL HEALTH AND PRODUCTION TECHNOLOGY', 'AHP', 'examofficer.ahp@fptb.edu.ng', '', 1),
(33, '1', 'LEISURE AND TOURISM MANAGEMENT', 'LTM', 'examofficer.ltm@fptb.edu.ng', '', 1),
(34, '6', 'LIBRARY AND INFORMATION SCIENCE', 'LIS', 'examofficer.lis@fptb.edu.ng', '', 1),
(35, '2', 'MECHATRONICS', 'MECT', 'examofficer.mec@fptb.edu.ng', '', 1),
(36, '2', 'COMPUTER ENGINEERING', 'COME', '', '', 1),
(37, '3', 'URBAND AND REGIONAL PLANNING', 'URP', 'examofficer.urp@fptb.edu.ng', '', 1),
(38, '6', 'CRIME MANAGEMENT', 'CMC', 'examofficer.cm@fptb.edu.ng', '', 1),
(39, '4', 'FISHERIES  TECHNOLOGY', 'FISH', '', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_depts`
--
ALTER TABLE `tbl_depts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_depts`
--
ALTER TABLE `tbl_depts`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
