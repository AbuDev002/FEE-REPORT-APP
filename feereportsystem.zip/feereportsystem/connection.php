<?php
$conms = @mysqli_connect('localhost','root','','fptbfees');
?>