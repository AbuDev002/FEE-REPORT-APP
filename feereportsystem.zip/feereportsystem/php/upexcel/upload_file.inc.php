<?php
		$error_msg ="";
	if(isset($_POST['btnScheduleOfFees'])){
		$fee_session = $_POST['fee_session'];
		$fee_stream = $_POST['fee_stream'];
		@$file1 = $_FILES['upload1'] ['tmp_name'];
	
		if($file1){
		$handle = fopen($file1,"r");
		
		while(($fileop = fgetcsv($handle,1000,",")) !== false){
				//$s_n = $fileop[0];
				$fee_type = $fileop[1];
				$class = $fileop[2];
				$registration = $fileop[3];
				$exams = $fileop[4];
				$games = $fileop[5];
				$library = $fileop[6];
				$idcard = $fileop[7];
				$verification = $fileop[8];
				$prospect = $fileop[9];
				$medical = $fileop[10];
				$technology = $fileop[11];
				$practical = $fileop[12];
				$tuition = $fileop[13];
				$endownment = $fileop[14];
				$eed = $fileop[15];
				$siwes = $fileop[16];
				$accomodation = $fileop[17];
				$total_fee = $fileop[18];
			
				$query = $db->insert("INSERT INTO feerecord (session,fee_type,class,registration,exams,games,library,idcard,verification,prospect,medical,technology,practical,tuition,endowment,eed,siwes,accomodation,total_fee,stream) VALUES('".$fee_session."','".$fee_type."','".$class."','".$registration."','".$exams."','".$games."','".$library."','".$idcard."','".$verification."','".$prospect."','".$medical."','".$technology."','".$practical."','".$tuition."','".$endownment."','".$eed."','".$siwes."','".$accomodation."','".$total_fee."','".$fee_stream."')") or die('Upload failed');
		
		}
		
			if($query){
					$error_msg ='<p class="alert alert-success">Schedule of fees uploaded successfully.</p>';
			
			}
		}else{
				$error_msg ='<p class="alert alert-warning">Please select schedule of fees list</>';
		}
	}


?>