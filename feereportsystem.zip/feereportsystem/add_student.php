<?php
session_start();
ob_start();
if(!isset($_SESSION['username'])){
	header('location:index.php');
}
?>
    <?php include_once('config/config.php');?>
        <?php include_once('lib/Database.php');?>
            <?php include_once('helpers/format.php');?>
                <?php	
	$db = new Database();
	$fm = new Format();
?>
                    <!DOCTYPE html>
                    <html lang="en">

                    <head>
                        <title>FPTB Fees Report | Add new Student</title>
                        <?php include_once('scripts/meta.php');?>
                            <?php include_once('scripts/css.php');?>
                    </head>

                    <body class="app sidebar-mini rtl">
                        <!-- Navbar-->
                        <?php include_once('incs/header.php');?>
                            <!-- Sidebar menu-->
                            <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
                            <?php include_once('incs/sidebar.php');?>
                                <main class="app-content">
                                    <div class="app-title">
                                        <div>
                                            <h1><i class="fa fa-hand-o-right"></i> Add Student</h1>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                        </div>
                                    </div>

                                    <form id="form" method="POST" action="admin/student/4" enctype="multipart/form-data">
                                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                                        <input type="hidden" name="_method" value="put">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="tile">
                                                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Personal Information</h4>
                                                    <div class="tile-body">

                                                        <div class="form-group">
                                                            <div class="left">
                                                                <img id="img-uploaded" src="http://placehold.it/350x350" alt="your image" />

                                                            </div>
                                                            <div class="right">

                                                                <input type="text" style="display: none" class="img-path" placeholder="Image Path">
                                                                <span class="file-wrapper">
  <input type="file" name="photo" id="imgInp" value="" class="uploader" />
  <span class="btn btn-large btn-alpha btn-primary">Upload Image</span>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label> <strong>Name</strong></label>
                                                            <input type="text" name="name" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Phone</strong></label>
                                                            <input type="text" name="mobile" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Email</strong></label>
                                                            <input type="email" name="email" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Birth Day</strong></label>
                                                            <div class="input-group">
                                                                <input type="text" class="form-control input-lg" name="b_day" value="" id="demoDate" placeholder="Select Date" required>
                                                                <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-calendar"></i>
                                            </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Religion</strong></label>
                                                            <select name="religion" class="form-control">
                                                                <option value="Islam">Islam</option>
                                                                <option value="Christianity">Christianity</option>
                                                                <option value="Others">Others</option>
                                                            </select>

                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Gender</strong></label>
                                                            <input data-toggle="toggle" data-on="Male" value="" data-off="Female" data-onstyle="success" data-offstyle="info" data-width="100%" type="checkbox" name="gender">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="tile">
                                                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Guardian Information</h4>
                                                    <div class="tile-body">

                                                        <div class="form-group">
                                                            <label> <strong>Guardian Name</strong></label>
                                                            <input type="text" name="guardian_name" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Guardian Phone</strong></label>
                                                            <input type="text" name="guardian_phone" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Guardian Email<small>(Optional)</small></strong></label>
                                                            <input type="email" name="guardian_email" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Guardian Occupation </strong></label>
                                                            <input type="text" name="guardian_ocu" value="" class="form-control input-lg">
                                                        </div>
                                                        <div class="form-group">
                                                            <label><strong>Relation With Student</strong></label>
                                                            <input type="text" name="guardian_relation" value="" class="form-control input-lg">
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>

                                            <div class="col-md-8">
                                                <div class="tile">
                                                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Admission Information</h4>
                                                    <div class="tile-body">
                                                        <div class="form-group row">
                                                            <div class="col-md-4">
                                                                <label><strong>Registratin No.</strong></label>
                                                                <input type="number" name="admission_number" value="" class="form-control input-lg">
                                                            </div>

                                                            <!--<div class="col-md-4">
                                                                <label><strong>Roll</strong></label>
                                                                <input type="number" name="roll" value="" class="form-control input-lg">
                                                            </div>-->

                                                            <div class="col-md-4">
                                                                <label><strong>Join Date</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control input-lg" name="join_date" id="demoDate1" value="" placeholder="Select Date" required>
                                                                    <div class="input-group-append"><span class="input-group-text">
                                            <i class="fa fa-calendar"></i>
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div class="form-group row">
                                                            <div class="col-md-6">
                                                                <label><strong>Department</strong></label>
                                                                <select class="form-control" name="cat_id" id="department">
                                                                    <option value="">--Select Department--</option>
																	<?php
																		 $getdept_sql ="SELECT * FROM departments";
																		 $getdept_qry = $db->select($getdept_sql);
																		 if($getdept_qry){
																		 while($getdept_rs = $getdept_qry->fetch_assoc()){
																	
																	?>
                                                                    <option value="<?php echo $getdept_rs['department'];?>"><?php echo $getdept_rs['department'];?></option>
                                                                 
																	<?php } }?>
																</select>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <label><strong>Class</strong></label>
                                                                <select class="form-control" name="subject_id" id="designation">
                                                                    <option value="">--Select Class</option>
                                                                    <option value="">Group A</option>
                                                                </select>
                                                            </div>

                                                        </div>

                                                        <div class="form-group row">
                                                            <div class="col-md-4">
                                                                <label><strong>Admission Fee</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" id="admisionFee" value="" class="form-control input-lg" readonly>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">
                                            $
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-4">
                                                                <label><strong>Monthly Fee</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" id="monthlyFee" value="" readonly class="form-control input-lg">
                                                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-4">
                                                                <label><strong>Discount <small>(Total Of Admission Fee)</small></strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" id="discount" value="" name="discount">
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">
                                        <select name="admission_discount_status" id="type">
                                            <option value="">Type</option>
                                            <option  value="2">%</option>
                                            <option  value="1">$</option>
                                        </select>
                                    </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div class="form-group row">

                                                            <div class="col-md-4">
                                                                <label><strong>After Discount Admission Fee</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" id="afterDis" value="" readonly class="form-control input-lg">
                                                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-4">
                                                                <label><strong>Advance</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control input-lg" value="" id="advance" name="advance">
                                                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-4">
                                                                <label><strong>Due</strong></label>
                                                                <div class="input-group">
                                                                    <input type="text" id="due" readonly value="" class="form-control input-lg">
                                                                    <div class="input-group-append"><span class="input-group-text">
                                            $
                                            </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="tile">
                                                    <h4 class="tile-title">
                        <i class="fa fa-user"></i>Others Information </h4>
                                                    <div class="tile-body">

                                                        <div class="form-group">
                                                            <label> <strong>Fathers Name</strong></label>
                                                            <input type="text" name="f_name" value="" class="form-control input-lg" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label> <strong>Mothers Name</strong></label>
                                                            <input type="text" name="m_name" value="" class="form-control input-lg" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label> <strong>Current Address</strong></label>
                                                            <textarea type="text" name="c_address" rows="3" class="form-control"></textarea>
                                                        </div>

                                                        <div class="form-group">
                                                            <label> <strong>Permanent Address</strong></label>
                                                            <textarea type="text" name="p_address" rows="3" class="form-control"></textarea>
                                                        </div>

                                                        <div class="form-group">
                                                            <label> <strong>Guardians Address</strong></label>
                                                            <textarea type="text" name="guardian_address" rows="3" class="form-control"></textarea>
                                                        </div>

                                                        <div class="form-group">
                                                            <label> <strong>Student's Document <small>(Optional)</small></strong></label>
                                                            <input type="file" name="b_certificate" class="form-control">

                                                            <a download href="assets/images/student/doc/1533389853.jpg">Download Student Document</a>
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>

                                            <button type="submit" class="btn btn-primary btn-block">Submit</button>
                                        </div>
                                    </form>

                                    <div class="modal fade" id="genInv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-cog'></i> Generate Invoice!</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                </div>

                                                <div class="modal-body">
                                                    <strong>Are you sure you want to Generate Invoice ? <br>
                        It will show you whose students until not pay their monthly term payment.</strong>
                                                </div>

                                                <div class="modal-footer">
                                                    <form method="post" action="admin/generate/pay">
                                                        <input type="hidden" name="_token" value="FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb">
                                                        <input type="hidden" name="id" id="deleteID">

                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-info">Yes Generate Now</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </main>
                                <!-- Essential javascripts for application to work-->
                                <script src="assets/admin/js/jquery-3.2.1.min.js"></script>
                                <script src="assets/admin/js/popper.min.js"></script>
                                <script src="assets/admin/js/bootstrap.min.js"></script>
                                <script src="assets/admin/js/bootstrap-toggle.min.js"></script>
                                <script src="assets/admin/js/bootstrap-fileinput.js" type="text/javascript"></script>
                                <script src="assets/admin/js/main.js"></script>
                                <!-- The javascript plugin to display page loading on top-->
                                <script src="assets/admin/js/pace.min.js"></script>
                                <!-- Page specific javascripts-->
                                <script type="text/javascript" src="assets/admin/js/jquery.dataTables.min.js"></script>
                                <script type="text/javascript" src="assets/admin/js/dataTables.bootstrap.min.js"></script>
                                <script type="text/javascript">
                                    $('#sampleTable').DataTable();
                                </script>

                                <script type="text/javascript" src="http://preview.thesoftking.com/thesoftking/itech/assets/admin/js/bootstrap-datepicker.min.js"></script>
                                <script>
                                    $('#demoDate').datepicker({
                                        format: "yyyy/mm/dd",
                                        autoclose: true,
                                        todayHighlight: true
                                    });

                                    $('#demoDate1').datepicker({
                                        format: "yyyy/mm/dd",
                                        autoclose: true,
                                        todayHighlight: true
                                    });
                                </script>
                                <script>
                                    $(document).ready(function() {

                                        var total = $('#afterDis').val();
                                        var advance = $('#advance').val();

                                        var due = Number(total) - Number(advance);
                                        $('#due').val(due);

                                        $(document).on('change', '#department', function() {
                                            var id = $(this).val();
                                            $('#discount').val(' ');
                                            $('#type').val(' ');

                                            $.ajax({
                                                type: "POST",
                                                url: "http://preview.thesoftking.com/thesoftking/itech/admin/student/cat/pass",
                                                data: {
                                                    'id': id,
                                                    '_token': "FRZBLuYT9JkefNE2YqfUaEk2OCFuWppeu9lez3fb"
                                                },
                                                success: function(data) {
                                                    $('#designation').html(data.output);
                                                    $('#admisionFee').val(data.cat_add_fee);
                                                    $('#monthlyFee').val(data.cat_monthly_fee);
                                                    $('#afterDis').val(data.cat_add_fee);

                                                    $(document).on('change', '#type', function() {
                                                        var total = data.cat_add_fee;
                                                        var type = $(this).val();
                                                        $('#advance').val(' ');

                                                        if (type == 1) {
                                                            if (total > Number($('#discount').val())) {
                                                                var val = total - Number($('#discount').val());
                                                                $('#afterDis').val(val);
                                                                return false;
                                                            } else {
                                                                alert('Invalid Amount');
                                                                $('#afterDis').val(' ');
                                                            }

                                                        } else {
                                                            var dis = (total * Number($('#discount').val())) / 100;
                                                            var val = total - dis;

                                                            if (Number(total) >= Number(Math.abs(val))) {
                                                                $('#afterDis').val(val);
                                                                return false;
                                                            } else {
                                                                alert('Invalid Amount');
                                                                $('#discount').val(' ');
                                                            }
                                                        }

                                                    });

                                                    $("#advance").click(function() {
                                                        $('#advance').val(' ');

                                                        var total = $('#afterDis').val();

                                                        $(document).on('keyup', '#advance', function() {

                                                            console.log($(this).val());

                                                            if (Number(total) >= $(this).val()) {
                                                                var due = Number(total) - Number($(this).val());
                                                                $('#due').val(due);
                                                            } else {
                                                                alert('Invalid Amount');
                                                                $('#advance').val('');
                                                                $('#due').val('');
                                                            };
                                                        });
                                                    });

                                                }
                                            });
                                        });

                                        $(document).on('change', '#type', function() {
                                            var total = $("#admisionFee").val();
                                            var type = $(this).val();
                                            $('#advance').val(' ');

                                            if (type == 1) {
                                                if (total > Number($('#discount').val())) {
                                                    var val = total - Number($('#discount').val());
                                                    $('#afterDis').val(val);
                                                    return false;
                                                } else {
                                                    alert('Invalid Amount');
                                                    $('#afterDis').val(' ');
                                                }

                                            } else {
                                                var dis = (total * Number($('#discount').val())) / 100;
                                                var val = total - dis;

                                                if (Number(total) >= Number(Math.abs(val))) {
                                                    $('#afterDis').val(val);
                                                    return false;
                                                } else {
                                                    alert('Invalid Amount');
                                                    $('#discount').val(' ');
                                                }
                                            }

                                        });

                                        $("#advance").click(function() {
                                            $('#advance').val(' ');

                                            var total = $('#afterDis').val();

                                            $(document).on('keyup', '#advance', function() {

                                                if (Number(total) >= $(this).val()) {
                                                    var due = Number(total) - Number($(this).val());
                                                    $('#due').val(due);
                                                } else {
                                                    alert('Invalid Amount');
                                                    $('#advance').val('');
                                                    $('#due').val('');
                                                };
                                            });
                                        });

                                        var SITE = SITE || {};

                                        SITE.fileInputs = function() {
                                            var $this = $(this),
                                                $val = $this.val(),
                                                valArray = $val.split('\\'),
                                                newVal = valArray[valArray.length - 1],
                                                $button = $this.siblings('.btn'),
                                                $fakeFile = $this.siblings('.file-holder');
                                            if (newVal !== '') {
                                                $button.text('Photo Chosen');
                                                if ($fakeFile.length === 0) {
                                                    $button.after('<span class="file-holder">' + newVal + '</span>');
                                                } else {
                                                    $fakeFile.text(newVal);
                                                }
                                            }
                                        };

                                        $('.file-wrapper input[type=file]').bind('change focus click', SITE.fileInputs);

                                        function readURL(input) {
                                            if (input.files && input.files[0]) {
                                                var reader = new FileReader();
                                                var tmppath = URL.createObjectURL(event.target.files[0]);

                                                reader.onload = function(e) {
                                                    $('#img-uploaded').attr('src', e.target.result);
                                                    $('input.img-path').val(tmppath);
                                                }

                                                reader.readAsDataURL(input.files[0]);
                                            }
                                        }

                                        $(".uploader").change(function() {
                                            readURL(this);
                                        });
                                    });
                                </script>

                    </body>

                    </html>