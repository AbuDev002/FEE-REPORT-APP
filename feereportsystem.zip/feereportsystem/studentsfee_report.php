<?php
        //session_start();
		ob_start();
		//error_reporting(1);
		require_once 'dompdf/autoload.inc.php';
		
?>
<?php include_once('config/config.php');?>
<?php include_once('lib/Database.php');?>
<?php include_once('helpers/format.php');?>
<?php	
	$db = new Database();
	$fm = new Format();
?>
<?php
	if(isset($_GET['thereport'])){
	$dept = $_GET['department'];
	$class = $_GET['class'];
	$stream = $_GET['stream'];
	
	}
?>
<!Doctype html>
<html>
	<head>
		<title>Student Fees Report</title>
		
		<style type="text/css">
			#container{
				width:1200px;
				height:auto;
				margin:0px auto;
				text-indent:5px;
                               
			}
			
			
			th#mdb{
				background-image:url("images/logo.png") no-repeat;
				background-size:contain;
			}
			
			#invt_details td{
				border:1px solid silver;
				border-collapse:collapse;
			}
			


			.head{
				background:#91C5D4;
				}
		@page { margin: 180px 50px; }
			#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 120px; background-color: #f5f5f5; text-align: center; width:100%; }
			#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 100px; background-color: #f5f5f5; }
			#footer .page:after { content: counter(page, upper-roman); }
			
			table#report_details{page-break-inside:avoid}
			
			
			
			/*table#secondsemster_gp tr td, table#secondsemster_gp tr th{page-break-after:auto;}
			table#thirdsemster_gp tr td, table#thirdsemster_gp tr th{page-break-after:auto;}
			table#fourthsemster_gp tr td, table#fourthsemster_gp tr th{page-break-after:auto;}*/
		  
		</style>
	</head>
	
<body>
<div id="container">
	
<div id="header">
		<table align="center"  width="100%" style="font-size:12px; border-collapse:collapse;">
			<tr>
				<td colspan="3" align="center"><img src="assets/images/logo/polylogo.jpg" width="50" height="50"></i></h3></td>
			</tr>
			<tr>
				<td colspan="3" align="center"><h3>FEDERAL POLYTECHNIC BAUCHI,<br/> <i>P.M.B 0231 BAUCHI, BAUCHI STATE</i></h3></td>
			</tr>
			
			<tr>
				<td></td>
				<td align="center"><br/><h2 style="padding:0px; background:#000; color:#fff;">STUDENTS SCHEDULE OF FEES REPORT</h2></td>
				<td></td>
			</tr>
			
		</table>
		<br/>
		<br/>
</div>
	<div id="footer">
	<table width="50%" align="center">
		<tr>
			<td width="400"><b>HOD SIGN/Stamp_______________________________</b></td>

		</tr>
	</table>
	<hr/>
	<br>
	<?php echo date('F j, Y');?>
	</div>	
			<table align="center" id="report_details"  width="100%" style="font-size:12px; border-collapse:collapse;">
				<?php
					 $getdp_sql ="SELECT * FROM departments WHERE dept_id= $dept";
					 $getdp_qry = $db->select($getdp_sql);
					 $getdp_rs = $getdp_qry->fetch_assoc();		 
				?>
				
				<?php
					 $getcl_sql ="SELECT * FROM addclass WHERE classid= $class";
					 $getcl_qry = $db->select($getcl_sql);
					 $getcl_rs = $getcl_qry->fetch_assoc();		 
				?>

				<?php
					 $getreport_sql ="SELECT * FROM student as std JOIN feerecord as fr WHERE std.dept_id = fr.dept_id AND std.class_id = fr.class_id AND std.class_id = $class AND std.dept_id= $dept AND fr.class_id = $class AND fr.dept_id=$dept AND fr.stream_id = $stream";
					 $getreport_qry = $db->select($getreport_sql);
					 if(@mysqli_num_rows($getreport_qry) > 0){
					 while($getreport_rs = $getreport_qry->fetch_assoc()){
						  $adm_session = $getreport_rs['joindate'];
						  $cls_stream = $getreport_rs['stream_id'];
						}
					}else{
						echo "<script>alert('No record found')</script>";
						echo "<script>window.open('fees_reports.php','_self')</script>";
					}
				?>
			<tr>
				<td><h2>SESSION: <?php echo @$adm_session;?></h2></td>
				<td align="center"><br/><h2>DEPARTMENT OF <?php echo $getdp_rs['department'];?>  &nbsp; &nbsp; &nbsp; CLASS: <?php echo $getcl_rs['classname'];?></h2></td>
				<td><h2>STREAM: <?php
					 $getst_sql ="SELECT * FROM stream WHERE stream_id= $cls_stream";
					 $getst_qry = $db->select($getst_sql);
					 $getst_rs = $getst_qry->fetch_assoc();	
					 echo $getst_rs['stream_name'];	 
				?></h2></td>
			</tr>
			</table>
			<table align="center" width="100%" border="1" class="table table-bordered" style="font-size:10px; border-collapse:collapse;"> 
			 <thead>      
				<tr>
				   
					<td align="center"><b>S/N</b></td>
					<td align="center"><b>MATRIC NO</b></td>
					<td align="center"><b>NAME</b></td>
					<td align="center"><b>REGISTRATION FEE</b></td>
					<td align="center"><b>EXAMS</b></td>
					<td align="center"><b>GAMES</b></td>
					<td align="center"><b>LIBRARY</b></td>
					<td align="center"><b>ID CARD</b></td>
					<td align="center"><b>VERIFICATION</b></td>
					<td align="center"><b>PROSPECTUS</b></td>
					<td align="center"><b>MEDICAL</b></td>
					<td align="center"><b>TECHNOLOGY</b></td>
					<td align="center"><b>PRACTICAL</b></td>
					<td align="center"><b>TUITION</b></td>
					<td align="center"><b>ENDOWNMENT</b></td>
					<td align="center"><b>EED</b></td>
					<td align="center"><b>SIWES</b></td>
					<td align="center"><b>TOTAL AMOUNT</b></td>
					
				</tr>
				</thead>
				<tbody>
				<?php
					 $sn =0;
					 $getreport_sql ="SELECT * FROM student as std JOIN feerecord as fr WHERE std.dept_id = fr.dept_id AND std.class_id = fr.class_id AND std.class_id = $class AND std.dept_id= $dept AND fr.class_id = $class AND fr.dept_id=$dept AND fr.stream_id = $stream";
					 $getreport_qry = $db->select($getreport_sql);
					 if($getreport_qry){
					 while($getreport_rs = $getreport_qry->fetch_assoc()){
						 $sn = $sn + 1;
				?>
				
				<tr>
					<td align="center"><?php echo $sn;?></td>
					<td align="center"><?php echo $getreport_rs['admin_no'];?></td>
					<td><?php echo $getreport_rs['sname'];?></td>
					<td align="center"><?php echo $getreport_rs['registration'];?></td>
					<td align="center"><?php echo $getreport_rs['exams'];?></td>
					<td align="center"><?php echo $getreport_rs['games'];?></td>
					<td align="center"><?php echo $getreport_rs['library'];?></td>
					<td align="center"><?php echo $getreport_rs['idcard'];?></td>
					<td align="center"><?php echo $getreport_rs['verification'];?></td>
					<td align="center"><?php echo $getreport_rs['prospect'];?></td>
					<td align="center"><?php echo $getreport_rs['medical'];?></td>
					<td align="center"><?php echo $getreport_rs['technology'];?></td>
					<td align="center"><?php echo $getreport_rs['practical'];?></td>
					<td align="center"><?php echo $getreport_rs['tuition'];?></td>
					<td align="center"><?php echo $getreport_rs['endowment'];?></td>
					<td align="center"><?php echo $getreport_rs['eed'];?></td>
					<td align="center"><?php echo $getreport_rs['siwes'];?></td>
					<td align="center">
						<?php 
							$totalfee = $getreport_rs['registration'] + $getreport_rs['exams'] + $getreport_rs['games'] + $getreport_rs['library'] + $getreport_rs['idcard'] + $getreport_rs['verification'] + $getreport_rs['prospect'] + $getreport_rs['medical'] + $getreport_rs['technology'] + $getreport_rs['practical'] + $getreport_rs['tuition'] + $getreport_rs['endowment'] + $getreport_rs['eed'] + $getreport_rs['siwes'];
							echo '<strong>'.$totalfee.'</strong>';

						?>
					</td>
				</tr>
				<?php }}?>
				</tbody>
			</table>
			<br/>
			
		</div>				   
	</body>
</html>
<?php		
	$html = ob_get_clean();
	use Dompdf\Dompdf;
	$dompdf = new DOMPDF();
	$dompdf->set_paper("Legal","Landscape");
	$dompdf->load_html($html);
	$dompdf->render();
	$dompdf->stream('overal_report.pdf');
?>