<?php

//$baseurl = "/feereportsystem.com/";
//$mainpage = "/";
?>
<!DOCTYPE html>
<html>

<!-- Mirrored from preview.thesoftking.com/thesoftking/itech/admin by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Oct 2018 16:20:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/images/logo/fav.jpg" />
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="assets/admin/css/font-awesome.min.css">
    <title>FPTB | Login Fees Report System</title>
    <style>
        #error{
            color: red;
        }
        .error
        {
            color: red;
        }
        .abir{
            display: fixed;
            z-index: 299;
            position: absolute;
            /*width: 85%;*/
            color: #FFF;
            background-color: #26a1ab;
            border-color: #26a1ab;
        }
        .slow-spin {
            -webkit-animation: fa-spin 2s infinite linear;
            animation: fa-spin 2s infinite linear;
        }
        .login-content .login-box {
            min-height: 455px;
        }
    </style>
</head>
<body>

<section class="login-content">
    <div class="logo">
        <img src="assets/images/logo/logo.png" class="img-responsive" style="max-width: 200px">
    </div>
    <div class="login-box">
        <form class="login-form" id="login-form" action="#" method="post">
            <!--<input type="hidden" name="_token" value="V2bpIBq9ip9ZVOIzRYUdaflmRWXUp61ASBnBIPst">-->
            <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN AS ADMIN</h3>
            <div id="error"></div>
            <div class="form-group">
                <label class="control-label">USERNAME</label>
                <input class="form-control" name="username" type="text" placeholder="Username" autofocus>
            </div>
            <div class="form-group">
                <label class="control-label">PASSWORD</label>
                <input class="form-control" name="password" type="password" placeholder="Password">
            </div>


            <div class="form-group btn-container" id="working">
                <button class="btn btn-success btn-block" ><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
            </div>
            <br>
            <a href="admin-password/reset.html">Forgot Password?</a>

        </form>

    </div>
</section>
<!-- Essential javascripts for application to work-->
<script src="assets/admin/js/jquery-3.2.1.min.js"></script>
<script src="assets/admin/js/popper.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
<script src="assets/admin/js/jquery.validate.min.js" type="text/javascript"></script>

<script src="assets/admin/js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="assets/admin/js/pace.min.js"></script>


<script>
    $('document').ready(function(){
        /* validation */
        $("#login-form").validate({
            rules:
                {
                    password: {
                        required: true,
                    },
                    username: {
                        required: true,
                    },
                },
            messages:
                {
                    password: "<span style='color: red'>Password is required.</span>",
                    username: "<span style='color: red'>Username is required.</span>",
                },
            submitHandler: submitForm
        });
        /* validation */

        /* login submit */
        function submitForm(){
            var data = $("#login-form").serialize();

            $.ajax({

                type : 'POST',
                url  : "checklogin.php",
                data : data,
                beforeSend: function()
                {
                    $("#error").fadeOut();
                    $("#working").html('<button class="btn btn-success btn-block" ><strong class="block" style="font-weight: bold;">  <i class = "fa fa-spinner slow-spin"></i>  Validating Your Data.... </strong></button>');
                },
                success :  function(response)
                {

                    if(response=="ok"){

                        $("#working").html('<button class="btn btn-success btn-block"> <i class="fa fa-spinner slow-spin"></i> Success! Processing to Dashboard...</button>');
                        setTimeout(' window.location.href = "dashboard.php"; ',3000);
                    }
                    else{

                        $("#error").fadeIn(1000, function(){
                            $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                            $("#working").html('<button class="btn btn-success btn-block" id="working"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>');
                        });
                    }
                },
                error :  function(response)
                {
                    $("#error").fadeIn(1000, function(){
                        $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                        $("#working").html('');
                    });

                }

            });
            return false;
        }
        /* login submit */
    });
</script>
</body>

<!-- Mirrored from preview.thesoftking.com/thesoftking/itech/admin by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Oct 2018 16:20:35 GMT -->
</html>